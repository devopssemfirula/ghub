import React from 'react';
import { X, ExternalLink, Sparkles, Zap, Beaker, Clock, Radio } from 'lucide-react';

interface NewsItem {
  id: string;
  title: string;
  category: 'AI Update' | 'New Release' | 'Experiment';
  date: string;
  link: string;
  icon: React.ElementType;
  color: string;
}

const NEWS_ITEMS: NewsItem[] = [
  {
    id: '1',
    title: 'Gemini 1.5 Pro now available in 180+ countries',
    category: 'AI Update',
    date: '2 hours ago',
    link: 'https://blog.google/technology/ai/google-gemini-update-flash-1-5-pro-1-5/',
    icon: Sparkles,
    color: 'text-blue-500'
  },
  {
    id: '2',
    title: 'NotebookLM adds audio overviews',
    category: 'New Release',
    date: '1 day ago',
    link: 'https://notebooklm.google.com/',
    icon: Zap,
    color: 'text-purple-500'
  },
  {
    id: '3',
    title: 'ImageFX gets updated photorealistic models',
    category: 'Experiment',
    date: '3 days ago',
    link: 'https://aitestkitchen.withgoogle.com/tools/image-fx',
    icon: Beaker,
    color: 'text-orange-500'
  },
  {
    id: '4',
    title: 'Project Astra: The future of multimodal AI assistants',
    category: 'AI Update',
    date: '1 week ago',
    link: 'https://deepmind.google/technologies/gemini/project-astra/',
    icon: Sparkles,
    color: 'text-blue-500'
  },
  {
    id: '5',
    title: 'Veo: Generative video model for high definition 1080p',
    category: 'New Release',
    date: '1 week ago',
    link: 'https://deepmind.google/technologies/veo/',
    icon: Zap,
    color: 'text-green-500'
  }
];

interface NewsRadarProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewsRadar: React.FC<NewsRadarProps> = ({ isOpen, onClose }) => {
  return (
    <>
      {/* M3 Scrim */}
      <div 
        className={`fixed inset-0 bg-black/40 backdrop-blur-[1px] transition-opacity z-[90] ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />
      
      {/* M3 Modal Side Sheet */}
      <div className={`
        fixed top-0 right-0 h-full w-[360px] bg-m3-surface-container-low shadow-elevation-3 z-[100] transform transition-transform duration-300 ease-[cubic-bezier(0.2,0,0,1)]
        rounded-l-[28px]
        ${isOpen ? 'translate-x-0' : 'translate-x-full'}
      `}>
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-6 flex items-center justify-between">
            <h2 className="text-xl font-normal font-display text-m3-on-surface">Radar</h2>
            <button 
              onClick={onClose}
              className="p-3 hover:bg-m3-on-surface/10 rounded-full transition-colors text-m3-on-surface-variant"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="px-6 pb-2">
             <div className="text-sm font-medium text-m3-on-surface-variant mb-4">Latest Updates</div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto px-4 space-y-2 custom-scrollbar pb-6">
            {NEWS_ITEMS.map((item) => (
              <a 
                key={item.id} 
                href={item.link} 
                target="_blank" 
                rel="noopener noreferrer"
                className="group block p-4 rounded-[16px] bg-m3-surface-container hover:bg-m3-surface-container-high hover:shadow-elevation-1 transition-all duration-200"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className={`p-2 rounded-full bg-m3-surface ${item.color}`}>
                    <item.icon className={`w-4 h-4`} />
                  </div>
                  <span className="text-[11px] font-medium text-m3-on-surface-variant bg-m3-surface px-2 py-1 rounded-full">
                    {item.date}
                  </span>
                </div>
                
                <h3 className="text-base font-medium text-m3-on-surface mb-1 leading-snug group-hover:text-m3-primary transition-colors font-display">
                  {item.title}
                </h3>
                
                <div className="flex items-center justify-between mt-3">
                  <span className="text-xs font-medium text-m3-on-surface-variant uppercase tracking-wide">
                    {item.category}
                  </span>
                  <ExternalLink className="w-4 h-4 text-m3-outline group-hover:text-m3-primary" />
                </div>
              </a>
            ))}
            
            <div className="p-6 rounded-[24px] bg-m3-primary-container mt-6 text-center">
              <h4 className="text-lg font-medium text-m3-on-primary-container mb-2 font-display">Explore Labs</h4>
              <p className="text-sm text-m3-on-primary-container/80 mb-4 leading-relaxed">
                Discover experimental AI tools and demos directly from Google's research teams.
              </p>
              <a 
                href="https://labs.google.com/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-sm font-medium text-m3-surface bg-m3-on-primary-container px-5 py-2.5 rounded-full inline-block hover:shadow-elevation-1 transition-shadow"
              >
                Visit Labs
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};