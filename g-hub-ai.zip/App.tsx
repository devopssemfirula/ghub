
import React, { useState, useEffect } from 'react';
import { SmartAssistant } from './components/SmartAssistant';
import { AppGrid } from './components/AppGrid';
import { NewsRadar } from './components/NewsRadar';
import { SideNavigation } from './components/SideNavigation';
import { IntroAnimation } from './components/IntroAnimation';
import { HomeFeed } from './components/HomeFeed';
import { GGNewsMenu } from './components/GGNewsMenu';
import { GemInsightsMenu } from './components/GemInsightsMenu';
import { ChatState } from './types';
import { getAssistantRecommendation } from './services/geminiService';
import { Menu, Radio, Sun, Moon, LogOut, Settings, User, Newspaper, Wand2 } from 'lucide-react';
import { GoogleIdentity } from './components/GoogleIdentity';

interface AppLogoProps {
  variant?: 'header' | 'hero';
  className?: string;
}

const AppLogo: React.FC<AppLogoProps> = ({ variant = 'header', className = '' }) => {
  const isHero = variant === 'hero';
  return (
    <div className={`flex items-center select-none cursor-default ${className}`}>
      <span className={`font-display font-medium tracking-tight flex items-baseline ${isHero ? 'text-[64px] sm:text-[92px] leading-none' : 'text-[24px]'}`}>
        <span className="text-[#4285F4]">G</span>
        <span className={`text-m3-on-surface ${isHero ? 'mx-2' : 'mx-[2px]'}`}>-</span>
        <span className="text-[#EA4335]">H</span>
        <span className="text-[#FBBC05]">u</span>
        <span className="text-[#34A853]">b</span>
      </span>
      <span className={`font-display text-m3-on-surface-variant font-normal tracking-normal ${isHero ? 'ml-3 sm:ml-5 text-[52px] sm:text-[76px] leading-none' : 'ml-2 text-[22px]'}`}>
        AI
      </span>
    </div>
  );
};

const App: React.FC = () => {
  const [chatState, setChatState] = useState<ChatState>({
    isLoading: false,
    response: null,
    error: null
  });
  
  const [showIntro, setShowIntro] = useState(true);
  const [isContentVisible, setIsContentVisible] = useState(false);
  const [currentQuery, setCurrentQuery] = useState('');
  const [recentQueries, setRecentQueries] = useState<string[]>([]);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [isRadarOpen, setIsRadarOpen] = useState(false);
  const [isGGNewsOpen, setIsGGNewsOpen] = useState(false);
  const [isGemInsightsOpen, setIsGemInsightsOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  useEffect(() => {
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setTheme('dark');
    }
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

  const handleSearch = async (query: string) => {
    // When user presses Enter, we still trigger the AI recommendation
    setRecentQueries(prev => [query, ...prev].slice(0, 5));
    setChatState({ isLoading: true, response: null, error: null });
    try {
      const result = await getAssistantRecommendation(query);
      setChatState({ isLoading: false, response: result, error: null });
    } catch (err) {
      setChatState({ isLoading: false, response: null, error: "Failed to reach AI assistant." });
    }
  };

  const handleClear = () => {
    setChatState({ isLoading: false, response: null, error: null });
    setCurrentQuery('');
    setSelectedCategory(null);
  };

  const handleTyping = (text: string) => {
      setCurrentQuery(text);
      // Clear AI recommendation if user starts typing something else to avoid confusion with live filter
      if (chatState.response && text.length > 0) {
        setChatState(prev => ({ ...prev, response: null }));
      }
  };

  const handleLoginSuccess = (user: any) => {
    setCurrentUser(user);
    setIsProfileOpen(false);
  };
  
  const handleIntroComplete = () => {
    setIsContentVisible(true);
    setTimeout(() => setShowIntro(false), 1000);
  };

  const recommendedApps = chatState.response?.recommendedApps || [];
  const activeFilter = currentQuery;
  const isSearching = !!currentQuery.trim();
  const isHome = !selectedCategory && !isSearching && recommendedApps.length === 0;

  return (
    <>
      {showIntro && <IntroAnimation onComplete={handleIntroComplete} />}

      <div className={`h-screen w-full bg-m3-surface text-m3-on-surface font-sans overflow-hidden selection:bg-m3-primary-container selection:text-m3-on-primary-container flex transition-opacity duration-1000 ${isContentVisible ? 'opacity-100' : 'opacity-0'}`}>
        
        <SideNavigation 
          isOpen={isSidebarOpen}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
          onCloseMobile={() => setIsSidebarOpen(false)}
        />

        <NewsRadar isOpen={isRadarOpen} onClose={() => setIsRadarOpen(false)} />

        <div className="flex-1 flex flex-col min-w-0 h-full relative transition-all duration-300 bg-m3-surface">
          
          <header className="flex-shrink-0 bg-m3-surface/90 backdrop-blur-md border-b border-m3-outline-variant/20 transition-all z-[80]">
            <div className="w-full px-4 sm:px-6 h-16 flex items-center justify-between">
              <div className="flex items-center gap-3">
                 <button 
                    onClick={() => setIsSidebarOpen(true)}
                    className="lg:hidden flex items-center justify-center w-10 h-10 rounded-full hover:bg-m3-surface-container-highest transition-colors focus:ring-2 focus:ring-m3-primary"
                    aria-label="Open Navigation"
                 >
                    <Menu className="w-6 h-6 text-m3-on-surface-variant" />
                 </button>
                 <div className={`flex items-center gap-3 transition-all duration-500 ${isHome ? 'opacity-0 -translate-x-4 pointer-events-none' : 'opacity-100 translate-x-0'}`}>
                   <AppLogo variant="header" />
                 </div>
              </div>

              <div className="flex items-center gap-2">
                 <div className="relative">
                   <button
                     onClick={() => setIsGemInsightsOpen(!isGemInsightsOpen)}
                     className={`
                       flex items-center gap-2 px-4 h-10 rounded-full transition-all font-medium text-sm
                       ${isGemInsightsOpen ? 'bg-purple-600 text-white shadow-elevation-1' : 'bg-m3-surface-container-highest text-m3-on-surface-variant hover:bg-m3-surface-container-high'}
                     `}
                     title="Gem Architect"
                   >
                     <Wand2 className={`w-4 h-4 ${isGemInsightsOpen ? 'animate-pulse' : ''}`} />
                     <span className="hidden lg:inline">Gem Insights</span>
                   </button>
                   <GemInsightsMenu 
                     isOpen={isGemInsightsOpen} 
                     onClose={() => setIsGemInsightsOpen(false)} 
                     recentQueries={recentQueries}
                   />
                 </div>

                 <div className="relative">
                   <button
                     onClick={() => setIsGGNewsOpen(!isGGNewsOpen)}
                     className={`
                       flex items-center gap-2 px-4 h-10 rounded-full transition-all font-medium text-sm
                       ${isGGNewsOpen ? 'bg-m3-primary text-m3-on-primary shadow-elevation-1' : 'bg-m3-surface-container-highest text-m3-on-surface-variant hover:bg-m3-surface-container-high'}
                     `}
                   >
                     <Newspaper className="w-4 h-4" />
                     <span className="hidden sm:inline">GGnews</span>
                   </button>
                   <GGNewsMenu isOpen={isGGNewsOpen} onClose={() => setIsGGNewsOpen(false)} />
                 </div>

                 <button onClick={toggleTheme} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-m3-surface-container-highest transition-colors text-m3-on-surface-variant focus:ring-2 focus:ring-m3-primary outline-none">
                   {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
                 </button>

                 <button onClick={() => setIsRadarOpen(true)} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-m3-surface-container-highest transition-colors relative text-m3-on-surface-variant focus:ring-2 focus:ring-m3-primary outline-none">
                   <Radio className="w-6 h-6" />
                   <span className="absolute top-2.5 right-2.5 flex h-2 w-2">
                     <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                     <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                   </span>
                 </button>

                 {currentUser ? (
                   <div className="relative ml-2">
                     <button className="w-10 h-10 rounded-full bg-m3-primary text-m3-on-primary font-medium text-sm flex items-center justify-center cursor-pointer hover:shadow-elevation-1 transition-shadow select-none focus:ring-2 focus:ring-m3-secondary" onClick={() => setIsProfileOpen(!isProfileOpen)}>
                       {currentUser.picture ? <img src={currentUser.picture} alt="Profile" className="w-full h-full rounded-full object-cover" /> : currentUser.name.charAt(0).toUpperCase()}
                     </button>
                     {isProfileOpen && (
                       <>
                          <div className="fixed inset-0 z-[90] cursor-default" onClick={() => setIsProfileOpen(false)} />
                          <div className="absolute right-0 top-12 mt-2 w-[320px] sm:w-[360px] bg-m3-surface-container rounded-[28px] shadow-elevation-3 z-[100] overflow-hidden animate-fadeIn flex flex-col ring-1 ring-black/5 origin-top-right">
                            <div className="px-4 pt-5 pb-4 flex flex-col items-center text-center">
                               <div className="w-16 h-16 rounded-full bg-m3-primary text-m3-on-primary flex items-center justify-center text-2xl font-medium mb-3 shadow-sm relative">
                                  {currentUser.picture ? <img src={currentUser.picture} alt="Profile" className="w-full h-full rounded-full object-cover" /> : currentUser.name.charAt(0).toUpperCase()}
                               </div>
                              <h2 className="text-lg font-medium text-m3-on-surface font-display truncate w-full">{currentUser.name}</h2>
                              <p className="text-sm text-m3-on-surface-variant mb-4 truncate w-full">{currentUser.email}</p>
                              <a href="https://myaccount.google.com/" target="_blank" rel="noopener noreferrer" className="px-5 py-2 rounded-[100px] border border-m3-outline text-m3-primary hover:bg-m3-primary/5 text-sm font-medium w-fit">Manage Account</a>
                            </div>
                            <div className="h-[1px] bg-m3-outline-variant/20 w-full"></div>
                            <div className="p-2 space-y-1">
                              <button className="w-full text-left px-4 py-3 rounded-full flex items-center gap-3 hover:bg-m3-on-surface/5 transition-colors text-sm font-medium text-m3-on-surface" onClick={() => { setCurrentUser(null); setIsProfileOpen(false); }}>
                                 <LogOut className="w-5 h-5 text-m3-on-surface-variant" /> Sign Out
                              </button>
                            </div>
                          </div>
                       </>
                     )}
                   </div>
                 ) : (
                   <div className="ml-2"><GoogleIdentity onLoginSuccess={handleLoginSuccess} /></div>
                 )}
              </div>
            </div>
          </header>

          <main className="flex-1 overflow-y-auto w-full custom-scrollbar px-4 sm:px-6 pt-12 pb-24 scroll-smooth">
            <div className="max-w-[1600px] mx-auto w-full">
              {isHome && (
                <div className="flex flex-col items-center justify-center mb-12 mt-8 sm:mt-16 text-center max-w-4xl mx-auto animate-fadeIn">
                  <div className="mb-8"><AppLogo variant="hero" /></div>
                  <div className="animate-slideUpFade" style={{ animationDelay: '0.8s' }}>
                    <h2 className="text-2xl sm:text-3xl font-display font-medium text-m3-on-surface mb-6 leading-tight">How can we help you?</h2>
                    <p className="text-lg sm:text-xl text-m3-on-surface-variant mb-12 max-w-2xl font-normal leading-relaxed text-center px-4">
                      Search for apps directly or describe your task to the AI assistant to get personalized recommendations and Gem insights.
                    </p>
                  </div>
                </div>
              )}
              
              <div className={`w-full max-w-[720px] mx-auto transition-all duration-500 ${isHome ? 'mb-12 animate-slideUpFade' : 'mb-8'}`} style={isHome ? { animationDelay: '1s' } : {}}>
                 <SmartAssistant 
                   onSearch={handleSearch} 
                   onInputChange={handleTyping} 
                   chatState={chatState} 
                   onClear={handleClear} 
                 />
              </div>

              {/* HomeFeed only shows when not searching and not browsing a category */}
              {isHome && <HomeFeed />}

              <div className="animate-fadeIn">
                <AppGrid 
                  recommendedApps={recommendedApps} 
                  filterQuery={activeFilter} 
                  isLoading={chatState.isLoading} 
                  selectedCategory={selectedCategory} 
                  onCategorySelect={setSelectedCategory} 
                />
              </div>
            </div>
          </main>

          <footer className="flex-shrink-0 py-6 border-t border-m3-outline-variant/20 bg-m3-surface z-10">
            <div className="max-w-[1600px] mx-auto px-6 text-center text-m3-on-surface-variant text-sm font-medium">
              <p>&copy; {new Date().getFullYear()} G-Hub AI. Desenvolvido por um apaixonado pela Google &lt;3</p>
            </div>
          </footer>
        </div>
      </div>
    </>
  );
};

export default App;
