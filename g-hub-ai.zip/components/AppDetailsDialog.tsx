import React from 'react';
import { GoogleApp } from '../types';
import { CATEGORY_DESCRIPTIONS } from '../constants';
import { X, ExternalLink, Info, ArrowRight } from 'lucide-react';

interface AppDetailsDialogProps {
  app: GoogleApp;
  isOpen: boolean;
  onClose: () => void;
  IconComponent: React.ElementType;
}

export const AppDetailsDialog: React.FC<AppDetailsDialogProps> = ({ 
  app, 
  isOpen, 
  onClose,
  IconComponent 
}) => {
  if (!isOpen) return null;

  const categoryDescription = CATEGORY_DESCRIPTIONS[app.category] || "Part of the Google ecosystem.";

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/40 backdrop-blur-[2px] z-[150] animate-fadeIn"
        onClick={onClose}
      />

      {/* Dialog Container */}
      <div className="fixed inset-0 z-[160] flex items-center justify-center p-4 pointer-events-none">
        
        {/* The Card Itself - "Jump Out" Animation applied here */}
        <div 
          className="bg-m3-surface-container-high w-full max-w-[600px] rounded-[32px] shadow-elevation-3 overflow-hidden animate-jumpOut pointer-events-auto flex flex-col max-h-[90vh] ring-1 ring-white/10"
          style={{ borderTop: `4px solid ${app.color}` }}
        >
          
          {/* Header Image/Color Area */}
          <div className="relative h-32 sm:h-40 w-full overflow-hidden">
             <div className="absolute inset-0 opacity-15" style={{ backgroundColor: app.color }}></div>
             <div className="absolute inset-0 bg-gradient-to-b from-transparent to-m3-surface-container-high"></div>
             
             <button 
                onClick={onClose}
                className="absolute top-4 right-4 p-2 rounded-full bg-black/10 hover:bg-black/20 text-m3-on-surface transition-colors focus:ring-2 focus:ring-m3-primary"
             >
               <X className="w-6 h-6" />
             </button>
          </div>

          {/* Body Content */}
          <div className="px-8 pb-8 -mt-12 relative flex flex-col flex-1 overflow-y-auto custom-scrollbar">
            
            {/* App Icon & Title */}
            <div className="flex items-end gap-6 mb-6">
              <div 
                className="w-24 h-24 rounded-[24px] flex items-center justify-center text-white shadow-md flex-shrink-0 transition-transform hover:scale-105 duration-300"
                style={{ backgroundColor: app.color }}
              >
                <IconComponent className="w-12 h-12" strokeWidth={1.5} />
              </div>
              <div className="pb-2">
                 <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-m3-surface-container-highest text-m3-on-surface-variant mb-2">
                    {app.category}
                 </div>
                 <h2 className="text-3xl sm:text-4xl font-display text-m3-on-surface leading-none tracking-tight">
                   {app.name}
                 </h2>
              </div>
            </div>

            {/* Main Descriptions */}
            <div className="space-y-6">
               
               {/* About the Sector/Initiative (The Request) */}
               <div className="bg-m3-secondary-container/30 p-5 rounded-[20px] border border-m3-outline-variant/10 hover:bg-m3-secondary-container/50 transition-colors duration-300">
                  <div className="flex items-center gap-2 mb-2 text-m3-primary">
                     <Info className="w-5 h-5" />
                     <h3 className="text-sm font-bold uppercase tracking-wider">About this Initiative</h3>
                  </div>
                  <p className="text-m3-on-surface text-base leading-relaxed">
                    {categoryDescription}
                  </p>
               </div>

               {/* About the App */}
               <div className="pl-2">
                  <h3 className="text-lg font-medium text-m3-on-surface mb-2 font-display">Description</h3>
                  <p className="text-m3-on-surface-variant text-base leading-relaxed">
                    {app.description}
                  </p>
               </div>
            </div>

            {/* Action Footer */}
            <div className="mt-8 flex justify-end">
              <a 
                href={app.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 bg-m3-primary text-m3-on-primary px-6 py-3 rounded-full font-medium hover:shadow-elevation-1 transition-all active:scale-95 group hover:bg-m3-primary/90"
              >
                <span>Open {app.name}</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};