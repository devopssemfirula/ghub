import React, { useState } from 'react';
import { AppCategory } from '../types';
import { API_DOCS_LINKS } from '../constants';
import { 
  Home, Grid, Zap, MessageCircle, Play, Box, Briefcase, 
  BookOpen, Monitor, Code, Sparkles, LayoutGrid, LucideIcon,
  ExternalLink, ChevronRight, BookText, Star, PanelLeftClose, PanelLeftOpen,
  Orbit
} from 'lucide-react';

interface SideNavigationProps {
  isOpen: boolean;
  selectedCategory: string | null;
  onSelectCategory: (category: string | null) => void;
  onCloseMobile: () => void;
}

const SECTIONS = [
  {
    title: 'Collections',
    items: [
      { name: 'Featured', icon: Star, id: 'Featured' },
      { name: 'Labs & Experimental', icon: Sparkles, id: AppCategory.LABS },
      { name: 'Alphabet (Moonshots)', icon: Orbit, id: AppCategory.ALPHABET }
    ]
  },
  {
    title: 'Categories',
    items: [
      { name: 'Productivity', icon: Zap, id: AppCategory.PRODUCTIVITY },
      { name: 'Communication', icon: MessageCircle, id: AppCategory.COMMUNICATION },
      { name: 'Utility', icon: Box, id: AppCategory.UTILITY },
      { name: 'Knowledge', icon: BookOpen, id: AppCategory.KNOWLEDGE },
      { name: 'Entertainment', icon: Play, id: AppCategory.ENTERTAINMENT },
      { name: 'Business', icon: Briefcase, id: AppCategory.BUSINESS }
    ]
  }
];

export const SideNavigation: React.FC<SideNavigationProps> = ({ 
  isOpen, 
  selectedCategory, 
  onSelectCategory,
  onCloseMobile
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const handleSelect = (category: string | null) => {
    onSelectCategory(category);
    onCloseMobile();
  };

  const toggleSidebar = () => {
    setIsCollapsed(!isCollapsed);
  };

  return (
    <>
      <div className={`fixed inset-0 bg-black/40 backdrop-blur-[1px] z-[90] lg:hidden transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={onCloseMobile} />
      <nav className={`fixed top-0 left-0 bottom-0 bg-m3-surface-container-low z-[100] flex flex-col border-r border-transparent lg:border-m3-outline-variant/10 transition-[width,transform] duration-500 ease-[cubic-bezier(0.2,0,0,1)] lg:translate-x-0 lg:sticky lg:h-screen lg:top-0 ${isOpen ? 'translate-x-0 shadow-elevation-2' : '-translate-x-full lg:shadow-none'} ${isCollapsed ? 'lg:w-[88px]' : 'lg:w-[300px] w-[300px]'}`}>
        <div className={`h-24 flex items-center px-7 flex-shrink-0 transition-opacity duration-300 ${isCollapsed ? 'lg:opacity-0' : 'opacity-100'}`}>
          <div className="flex items-center select-none cursor-default">
            <span className="font-display font-medium tracking-tight flex items-baseline text-[22px]">
              <span className="text-[#4285F4]">G</span>
              <span className="text-m3-on-surface mx-[1px]">-</span>
              <span className="text-[#EA4335]">H</span>
              <span className="text-[#FBBC05]">u</span>
              <span className="text-[#34A853]">b</span>
            </span>
            <span className="font-display text-m3-on-surface-variant font-normal tracking-normal ml-2 text-[20px]">AI</span>
          </div>
        </div>
        <div className="h-6 hidden lg:block flex-shrink-0"></div>
        <div className="flex-1 overflow-y-auto overflow-x-hidden px-3 pb-6 custom-scrollbar">
          <div className="mb-2">
            <button onClick={() => handleSelect(null)} className={`w-full flex items-center h-[56px] rounded-full transition-all duration-300 ${!selectedCategory ? 'bg-m3-secondary-container text-m3-on-secondary-container' : 'text-m3-on-surface-variant hover:bg-m3-surface-container-high hover:text-m3-on-surface'} ${isCollapsed ? 'justify-center px-0' : 'justify-start px-4'}`}>
              <Home className={`w-[24px] h-[24px] transition-all duration-300 ${isCollapsed ? 'mr-0' : 'mr-3'}`} />
              <span className={`whitespace-nowrap transition-all duration-300 ${isCollapsed ? 'opacity-0 w-0 overflow-hidden' : 'opacity-100 w-auto font-medium text-sm tracking-wide'}`}>Home</span>
            </button>
          </div>
          {SECTIONS.map((section) => (
            <div key={section.title}>
              <div className={`mb-2 px-4 text-xs font-medium text-m3-on-surface-variant/80 uppercase tracking-wider mt-4 transition-all duration-300 ${isCollapsed ? 'h-0 opacity-0 mb-0' : 'h-auto opacity-100'}`}>{section.title}</div>
              <div className="space-y-1">
                {section.items.map((item) => (
                  <button key={item.id} onClick={() => handleSelect(item.id)} className={`w-full flex items-center h-[56px] rounded-full transition-all duration-300 ${selectedCategory === item.id ? 'bg-m3-secondary-container text-m3-on-secondary-container' : 'text-m3-on-surface-variant hover:bg-m3-surface-container-high hover:text-m3-on-surface'} ${isCollapsed ? 'justify-center px-0' : 'justify-start px-4'}`}>
                    <item.icon className={`w-[24px] h-[24px] transition-all duration-300 ${isCollapsed ? 'mr-0' : 'mr-3'}`} strokeWidth={2} />
                    <span className={`whitespace-nowrap transition-all duration-300 ${isCollapsed ? 'opacity-0 w-0 overflow-hidden' : 'opacity-100 w-auto font-medium text-sm'}`}>{item.name}</span>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div className="hidden lg:flex p-3 border-t border-m3-outline-variant/10 bg-m3-surface-container-low mt-auto">
          <button onClick={toggleSidebar} className={`flex items-center h-[48px] rounded-full text-m3-on-surface-variant hover:bg-m3-surface-container-high hover:text-m3-on-surface transition-all duration-300 ${isCollapsed ? 'w-full justify-center px-0' : 'w-full justify-start px-4'}`}>
            {isCollapsed ? <PanelLeftOpen className="w-[24px] h-[24px]" /> : <PanelLeftClose className="w-[24px] h-[24px] mr-3" />}
            <span className={`whitespace-nowrap transition-all duration-300 ${isCollapsed ? 'opacity-0 w-0 overflow-hidden' : 'opacity-100 w-auto font-medium text-sm'}`}>Collapse</span>
          </button>
        </div>
      </nav>
    </>
  );
};