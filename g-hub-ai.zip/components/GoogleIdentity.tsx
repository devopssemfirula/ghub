
import React, { useEffect, useRef, useState } from 'react';

// Declaration for the Google Identity Services global object
declare global {
  interface Window {
    google?: {
      accounts: {
        id: {
          initialize: (config: any) => void;
          renderButton: (parent: HTMLElement, options: any) => void;
          prompt: () => void;
          disableAutoSelect: () => void;
        }
      }
    };
  }
}

interface GoogleIdentityProps {
  onLoginSuccess: (user: any) => void;
  clientId?: string; // Optional: If user provides one
}

export const GoogleIdentity: React.FC<GoogleIdentityProps> = ({ onLoginSuccess, clientId }) => {
  const buttonRef = useRef<HTMLDivElement>(null);
  const [scriptLoaded, setScriptLoaded] = useState(false);
  const [initFailed, setInitFailed] = useState(false);
  
  // Updated public demo Client ID
  const FINAL_CLIENT_ID = clientId || '569343385310-137255146602073747831006.apps.googleusercontent.com';

  useEffect(() => {
    // Check if script is already loaded
    if (window.google?.accounts) {
      setScriptLoaded(true);
      return;
    }

    // Wait for the script tag in index.html to load
    const checkScript = setInterval(() => {
      if (window.google?.accounts) {
        setScriptLoaded(true);
        clearInterval(checkScript);
      }
    }, 100);

    return () => clearInterval(checkScript);
  }, []);

  const parseJwt = (token: string) => {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
          return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
      }).join(''));
      return JSON.parse(jsonPayload);
    } catch (e) {
      console.error("Failed to parse JWT", e);
      return null;
    }
  };

  useEffect(() => {
    if (scriptLoaded && window.google) {
      try {
        setInitFailed(false); // Reset failure state on new attempt
        window.google.accounts.id.initialize({
          client_id: FINAL_CLIENT_ID,
          callback: (response: any) => {
            if (response.credential) {
               const payload = parseJwt(response.credential);
               if (payload) {
                 onLoginSuccess({
                   name: payload.name,
                   email: payload.email,
                   picture: payload.picture,
                   sub: payload.sub
                 });
               }
            }
          },
          auto_select: false,
          cancel_on_tap_outside: true,
          use_fedcm_for_prompt: false
        });

        // NOTE: We removed window.google.accounts.id.prompt() here because it triggers 
        // a "FedCM get() rejects with NotAllowedError" in restricted iframe environments (like StackBlitz/WebContainers)
        // where the 'identity-credentials-get' permission policy is missing.
        // Users can still sign in using the rendered button or the demo fallback.

        if (buttonRef.current) {
          window.google.accounts.id.renderButton(
            buttonRef.current,
            { 
              theme: 'outline', 
              size: 'large',
              type: 'icon',
              shape: 'circle',
              logo_alignment: 'left'
            } 
          );
        }
      } catch (e) {
        console.warn("Google Sign-In initialization failed.", e);
        setInitFailed(true);
      }
    }
  }, [scriptLoaded, onLoginSuccess, FINAL_CLIENT_ID]);

  return (
    <div className="flex items-center justify-center gap-2">
      {/* The container for the official Google button */}
      <div ref={buttonRef} className="h-[40px] w-[40px] flex items-center justify-center overflow-hidden rounded-full"></div>
      
      {/* Always show Demo Button as an alternative option since public keys can be volatile */}
      <button 
        onClick={() => onLoginSuccess({ 
          name: "Guest User", 
          email: "guest@example.com",
          picture: "" 
        })}
        className="w-10 h-10 rounded-full border border-m3-outline/20 bg-transparent flex items-center justify-center text-m3-on-surface hover:bg-m3-surface-container-high transition-colors"
        title="Guest Access (Demo)"
      >
        <svg viewBox="0 0 24 24" className="w-5 h-5 opacity-70" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
          <circle cx="12" cy="7" r="4"></circle>
        </svg>
      </button>
    </div>
  );
};
