import React, { useState, useRef } from 'react';
import { Search, Sparkles, X, ArrowRight } from 'lucide-react';
import { ChatState } from '../types';

interface SmartAssistantProps {
  onSearch: (query: string) => void;
  onInputChange: (text: string) => void;
  chatState: ChatState;
  onClear: () => void;
}

export const SmartAssistant: React.FC<SmartAssistantProps> = ({ onSearch, onInputChange, chatState, onClear }) => {
  const [input, setInput] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      onSearch(input);
    }
  };

  const handleClear = () => {
    setInput('');
    onInputChange('');
    onClear();
    if (inputRef.current) inputRef.current.focus();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setInput(newValue);
    onInputChange(newValue);
  };

  return (
    <div className="w-full max-w-[720px] mx-auto relative z-10">
      <form onSubmit={handleSubmit} className="relative">
        
        {/* M3 Search Bar Container */}
        <div className={`
          relative flex items-center w-full min-h-[56px] rounded-full transition-all duration-200 ease-out
          ${isFocused || input.trim() ? 'bg-m3-surface-container-high shadow-elevation-2' : 'bg-m3-surface-container-high shadow-none hover:bg-m3-surface-container-highest hover:shadow-elevation-1'}
        `}>
          
          {/* Leading Icon */}
          <div className="pl-4 pr-2 flex items-center justify-center h-full">
            {chatState.isLoading ? (
              <Sparkles className="w-6 h-6 text-m3-primary animate-spin" strokeWidth={2} />
            ) : (
              <Search className="w-6 h-6 text-m3-on-surface-variant" strokeWidth={2} />
            )}
          </div>
          
          {/* Input Field */}
          <input
            ref={inputRef}
            type="text"
            className="flex-grow bg-transparent outline-none text-lg text-m3-on-surface placeholder-m3-on-surface-variant/70 font-normal h-full py-3"
            placeholder="Search apps or ask AI..."
            value={input}
            onChange={handleChange}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            disabled={chatState.isLoading}
          />

          {/* Trailing Icons */}
          <div className="pr-2 flex items-center gap-1">
            {input && (
              <button 
                type="button" 
                onClick={handleClear}
                className="p-3 rounded-full hover:bg-m3-on-surface/10 text-m3-on-surface-variant transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            )}
            
            {/* Submit Button (only prominent when needed) */}
             <button 
              type="submit" 
              disabled={!input.trim() || chatState.isLoading}
              className={`
                p-3 rounded-full transition-all duration-200
                ${input.trim() ? 'text-m3-primary bg-m3-primary-container hover:shadow-elevation-1' : 'text-m3-outline opacity-0 pointer-events-none'}
              `}
            >
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </form>

      {/* AI Response Card - M3 Elevated Card */}
      {(chatState.response || chatState.error) && (
        <div className="mt-4 p-6 bg-m3-surface-container-low rounded-[20px] shadow-elevation-1 border border-m3-outline-variant/30 text-center animate-fadeIn mx-4">
          {chatState.error ? (
            <p className="text-m3-error text-sm">{chatState.error}</p>
          ) : (
            <div className="flex flex-col items-center">
               <div className="flex items-center space-x-2 mb-2 bg-m3-secondary-container px-3 py-1 rounded-lg">
                 <Sparkles className="w-4 h-4 text-m3-on-secondary-container" />
                 <span className="text-xs font-bold text-m3-on-secondary-container uppercase tracking-wider">Suggestion</span>
               </div>
               <p className="text-m3-on-surface text-lg font-medium leading-relaxed">{chatState.response?.message}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};