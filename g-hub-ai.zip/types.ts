export interface GoogleApp {
  id: string;
  name: string;
  url: string;
  category: AppCategory;
  color: string;
  description: string;
}

export enum AppCategory {
  PRODUCTIVITY = 'Productivity',
  COMMUNICATION = 'Communication',
  ENTERTAINMENT = 'Entertainment',
  UTILITY = 'Utility',
  BUSINESS = 'Business',
  KNOWLEDGE = 'Knowledge',
  HARDWARE = 'Hardware',
  DEVELOPER = 'Developer',
  LABS = 'Labs & Experimental',
  ALPHABET = 'Alphabet (Other Bets)',
  OTHER = 'Other'
}

export interface AssistantResponse {
  message: string;
  recommendedApps: string[]; 
}

export interface GemInsight {
  id: string;
  name: string;
  purpose: string;
  type: 'Professional' | 'Personal';
  instructions: string;
  icon: string;
}

export interface ChatState {
  isLoading: boolean;
  response: AssistantResponse | null;
  error: string | null;
}