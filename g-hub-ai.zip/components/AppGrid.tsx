
import React, { useMemo, useState, useEffect, useRef } from 'react';
import { AppCard } from './AppCard';
import { GOOGLE_APPS, FEATURED_APP_IDS } from '../constants';
import { AppCategory, GoogleApp } from '../types';
import { 
  Zap, MessageCircle, Play, Box, Briefcase, BookOpen, Monitor, Code, 
  LayoutGrid, LucideIcon, Star, Search, Sparkles, Check, ChevronLeft, ChevronRight
} from 'lucide-react';

interface AppGridProps {
  recommendedApps: string[];
  filterQuery: string;
  isLoading?: boolean;
  selectedCategory: string | null;
  onCategorySelect: (category: string | null) => void;
}

const ITEMS_PER_PAGE = 24;

const LoadingGrid = () => (
  <div className="space-y-12 pb-24" aria-busy="true" aria-label="Loading apps">
    {[1, 2].map((section) => (
      <div key={section} className="animate-fadeIn">
        <div className="flex items-center mb-6 px-2">
          <div className="h-8 w-32 bg-m3-surface-container-high rounded-lg animate-pulse"></div>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 sm:gap-6 px-2">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="col-span-1 h-48 bg-m3-surface-container-low rounded-[24px] animate-pulse"></div>
          ))}
        </div>
      </div>
    ))}
  </div>
);

export const AppGrid: React.FC<AppGridProps> = ({ 
  recommendedApps, 
  filterQuery, 
  isLoading = false,
  selectedCategory,
  onCategorySelect
}) => {
  const [expandedAppId, setExpandedAppId] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const carouselRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  
  const activeQuery = filterQuery.toLowerCase().trim();
  const isHome = !selectedCategory && !activeQuery && recommendedApps.length === 0;

  // Reset page when filters change
  useEffect(() => {
    setCurrentPage(1);
    setExpandedAppId(null);
  }, [activeQuery, selectedCategory, recommendedApps]);

  const featuredApps = useMemo(() => {
    return GOOGLE_APPS.filter(app => FEATURED_APP_IDS.includes(app.id));
  }, []);

  const processedApps = useMemo(() => {
    let apps = [...GOOGLE_APPS];

    if (selectedCategory) {
      if (selectedCategory === 'Featured') {
         apps = apps.filter(app => FEATURED_APP_IDS.includes(app.id));
      } else {
         apps = apps.filter(app => app.category === selectedCategory);
      }
    }

    if (activeQuery) {
      apps = apps.filter(app => 
        app.name.toLowerCase().includes(activeQuery) || 
        app.category.toLowerCase().includes(activeQuery) ||
        app.description.toLowerCase().includes(activeQuery)
      );
    }

    // Sort by recommendation relevance first, then name
    apps.sort((a, b) => {
      const isARec = recommendedApps.includes(a.name);
      const isBRec = recommendedApps.includes(b.name);
      
      if (isARec && !isBRec) return -1;
      if (!isARec && isBRec) return 1;
      return a.name.localeCompare(b.name);
    });

    return apps;
  }, [activeQuery, recommendedApps, selectedCategory]);

  // Pagination Logic
  const totalItems = processedApps.length;
  const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const paginatedApps = processedApps.slice(startIndex, startIndex + ITEMS_PER_PAGE);

  const handlePageChange = (newPage: number) => {
    setCurrentPage(newPage);
    if (gridRef.current) {
      gridRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleCardToggle = (id: string) => {
    setExpandedAppId(prev => prev === id ? null : id);
  };

  const scrollCarousel = (direction: 'left' | 'right') => {
    if (!carouselRef.current) return;
    const scrollAmount = 400;
    carouselRef.current.scrollBy({
      left: direction === 'left' ? -scrollAmount : scrollAmount,
      behavior: 'smooth'
    });
  };

  if (isLoading) {
    return <LoadingGrid />;
  }

  // If literally nothing is happening, don't show the grid component at all
  if (isHome) {
    return null;
  }

  const isSearchMode = !!activeQuery;
  const title = activeQuery 
    ? `Results for "${filterQuery}"` 
    : (selectedCategory || (recommendedApps.length > 0 ? "Recommended" : "All Apps"));

  return (
    <div ref={gridRef} className="space-y-12 pb-24 animate-fadeIn" role="region" aria-label="App Directory">
      
      {/* Featured Apps Carousel (Hidden during search to focus on results) */}
      {!isSearchMode && (!selectedCategory || selectedCategory === 'Featured') && currentPage === 1 && (
        <section className="space-y-6 px-2 animate-fadeIn">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-m3-primary/10 text-m3-primary">
                <Star className="w-5 h-5 fill-current" />
              </div>
              <h2 className="text-2xl font-display font-medium text-m3-on-surface">Featured Apps</h2>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={() => scrollCarousel('left')}
                className="p-2 rounded-full border border-m3-outline-variant hover:bg-m3-surface-container-highest transition-colors"
                aria-label="Scroll Left"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button 
                onClick={() => scrollCarousel('right')}
                className="p-2 rounded-full border border-m3-outline-variant hover:bg-m3-surface-container-highest transition-colors"
                aria-label="Scroll Right"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
          
          <div 
            ref={carouselRef}
            className="flex gap-6 overflow-x-auto pb-6 scrollbar-hide snap-x snap-mandatory custom-scrollbar"
            style={{ scrollbarWidth: 'none' }}
          >
            {featuredApps.map(app => (
              <div key={`featured-${app.id}`} className="flex-shrink-0 w-[280px] sm:w-[320px] snap-start">
                <AppCard 
                  app={app} 
                  isRecommended={false}
                  isActive={expandedAppId === `feat-${app.id}`}
                  onToggle={() => handleCardToggle(`feat-${app.id}`)}
                />
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Main Grid Header */}
      <div className="px-2 flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-3xl font-display font-normal text-m3-on-surface transition-all duration-300">
            {title}
          </h2>
          <p className="text-sm text-m3-on-surface-variant mt-2 opacity-60">
            Showing {startIndex + 1}-{Math.min(startIndex + ITEMS_PER_PAGE, totalItems)} of {totalItems} items
          </p>
        </div>
        
        {/* Top Pagination Controls (if needed for quick access) */}
        {totalPages > 1 && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className="p-2 rounded-full border border-m3-outline-variant/30 hover:bg-m3-surface-container-highest disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <span className="text-sm font-medium px-2">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              className="p-2 rounded-full border border-m3-outline-variant/30 hover:bg-m3-surface-container-highest disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>

      {processedApps.length === 0 && (
        <div className="text-center py-20 opacity-60 animate-fadeIn">
          <div className="mb-4 flex justify-center">
            <Search className="w-12 h-12 text-m3-outline-variant" />
          </div>
          <p className="text-lg text-m3-on-surface-variant">No apps found matching "{filterQuery}"</p>
          <p className="text-sm text-m3-on-surface-variant/70 mt-1">Try a different search term or browse categories.</p>
        </div>
      )}

      <div className="space-y-12">
        <div className="animate-fadeIn">
          <div 
            className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 sm:gap-6 px-2 grid-flow-row-dense"
            role="list"
          >
            {paginatedApps.map(app => {
              const isExpanded = expandedAppId === app.id;
              
              return (
                <div 
                  key={app.id} 
                  role="listitem"
                  className={`
                    transition-all duration-500 ease-emphasized
                    ${isExpanded 
                      ? 'col-span-2 sm:col-span-3 md:col-span-4 lg:col-span-5 xl:col-span-6 row-span-2 z-10' 
                      : 'col-span-1 row-span-1 z-0'
                    }
                  `}
                >
                  <AppCard 
                    app={app} 
                    isRecommended={recommendedApps.includes(app.name)}
                    isActive={isExpanded}
                    onToggle={() => handleCardToggle(app.id)}
                  />
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Bottom Pagination Footer */}
      {totalPages > 1 && (
        <div className="flex justify-center mt-12 animate-fadeIn">
           <nav className="flex items-center gap-2 p-2 rounded-full bg-m3-surface-container-low shadow-sm border border-m3-outline-variant/10">
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-m3-surface-container-high disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                aria-label="Previous Page"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              
              <div className="hidden sm:flex items-center gap-1 px-2">
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  // Logic to show a window of pages around current page could go here
                  // For simplicity in this demo, showing first 5 or adjusting based on logic
                  let pageNum = i + 1;
                  if (totalPages > 5 && currentPage > 3) {
                     pageNum = currentPage - 2 + i;
                  }
                  if (pageNum > totalPages) return null;

                  return (
                    <button
                      key={pageNum}
                      onClick={() => handlePageChange(pageNum)}
                      className={`w-10 h-10 rounded-full text-sm font-medium transition-colors ${
                        currentPage === pageNum 
                          ? 'bg-m3-primary text-m3-on-primary' 
                          : 'text-m3-on-surface-variant hover:bg-m3-surface-container-highest'
                      }`}
                    >
                      {pageNum}
                    </button>
                  );
                })}
              </div>

              <span className="sm:hidden text-sm font-medium px-4">
                 {currentPage} / {totalPages}
              </span>

              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-m3-surface-container-high disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                aria-label="Next Page"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
           </nav>
        </div>
      )}
    </div>
  );
};
