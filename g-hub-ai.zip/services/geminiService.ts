
import { GoogleGenAI, Type } from "@google/genai";
import { AssistantResponse, GemInsight } from '../types';
import { GOOGLE_APPS } from '../constants';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// --- ASSISTANT ---
export const getAssistantRecommendation = async (userQuery: string): Promise<AssistantResponse> => {
  const allAppNames = GOOGLE_APPS.map(app => app.name).join(", ");

  const systemInstruction = `
    You are an intelligent workspace assistant for a Google Apps dashboard.
    Recommend the most relevant apps from: [${allAppNames}]
    Return JSON with 'message' and 'recommendedApps' (exact names).
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userQuery,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            message: { type: Type.STRING },
            recommendedApps: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["message", "recommendedApps"]
        }
      }
    });

    return JSON.parse(response.text || '{}') as AssistantResponse;
  } catch (error) {
    return {
      message: "I'm having trouble connecting. Browse the apps below.",
      recommendedApps: []
    };
  }
};

// --- GEM ARCHITECT ---
export const generateGemInsights = async (recentActivities: string[]): Promise<GemInsight[]> => {
  const context = recentActivities.length > 0 
    ? `The user recently searched for or worked on: ${recentActivities.join(", ")}.`
    : "The user is exploring the Google ecosystem for productivity.";

  const systemInstruction = `
    You are a 'Gem Architect'. Your goal is to suggest Custom AI Agents (Gems) for the user to create on gemini.google.com/gems.
    Based on the user context, generate 3 highly specific Gem ideas.
    
    Format each Gem with:
    1. 'name': Catchy name (e.g., 'Email Ghostwriter', 'Fitness Strategist').
    2. 'purpose': Short explanation of why this Gem is useful.
    3. 'type': 'Professional' or 'Personal'.
    4. 'instructions': Detailed 'System Instructions' the user should paste into the Gem creator.
    5. 'icon': A Lucide icon name (e.g., 'Code', 'Dumbbell', 'Mail', 'Zap').

    Return a JSON array of objects.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Generate 3 Gem insights based on this context: ${context}`,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              name: { type: Type.STRING },
              purpose: { type: Type.STRING },
              type: { type: Type.STRING, enum: ['Professional', 'Personal'] },
              instructions: { type: Type.STRING },
              icon: { type: Type.STRING }
            },
            required: ["name", "purpose", "type", "instructions", "icon"]
          }
        }
      }
    });

    const parsed = JSON.parse(response.text || '[]');
    return parsed.map((item: any, idx: number) => ({ ...item, id: `gem-${idx}` }));
  } catch (error) {
    console.error("Gem Architect Error:", error);
    return [];
  }
};

// --- ICON GENERATION WITH QUEUE ---

interface IconTask {
  name: string;
  description: string;
  resolve: (url: string | null) => void;
}

const iconQueue: IconTask[] = [];
let isProcessingQueue = false;

const processIconQueue = async () => {
  if (isProcessingQueue || iconQueue.length === 0) return;
  isProcessingQueue = true;

  while (iconQueue.length > 0) {
    const task = iconQueue[0]; // Peek at the first task

    try {
      // Call the internal generator
      const iconUrl = await generateIconInternal(task.name, task.description);
      
      // If successful, resolve and remove from queue
      task.resolve(iconUrl);
      iconQueue.shift();

      // Basic rate limiting: wait 2 seconds between successful calls to stay within free tier limits
      await new Promise(resolve => setTimeout(resolve, 2000));

    } catch (error: any) {
      // Check for Rate Limit / Quota Exceeded (429)
      if (error.status === 429 || error.message?.includes('429') || error.message?.includes('Quota exceeded')) {
        console.warn(`Quota exceeded for ${task.name}. Pausing queue for 15 seconds...`);
        // Do NOT remove the task. Wait and try again.
        await new Promise(resolve => setTimeout(resolve, 15000));
      } else {
        // Other errors (e.g. 500, network), fail this task and move on
        console.error(`Failed to generate icon for ${task.name}:`, error);
        task.resolve(null);
        iconQueue.shift();
      }
    }
  }

  isProcessingQueue = false;
};

const generateIconInternal = async (name: string, description: string): Promise<string | null> => {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: `Generate a minimalist, modern app icon for "${name}". 
    Description: ${description}. 
    Style: Flat vector, bold symbol, vibrant Google-inspired colors (blue, red, yellow, green). 
    Centered on a plain white background. Professional and high-contrast. No text.`,
    config: {
      imageConfig: {
        aspectRatio: "1:1"
      }
    }
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  return null;
};

export const generateAppIcon = (name: string, description: string): Promise<string | null> => {
  return new Promise((resolve) => {
    iconQueue.push({ name, description, resolve });
    processIconQueue();
  });
};
