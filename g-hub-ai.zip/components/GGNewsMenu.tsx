import React from 'react';
import { Newspaper, ExternalLink, Sparkles, Zap, TrendingUp, ArrowRight } from 'lucide-react';

interface NewsItem {
  id: string;
  title: string;
  source: string;
  category: 'AI' | 'Product' | 'Company' | 'Dev';
  time: string;
  url: string;
}

const GOOGLE_NEWS: NewsItem[] = [
  {
    id: 'n1',
    title: 'Gemini 1.5 Flash: Now faster and more efficient for developers',
    source: 'Google AI Blog',
    category: 'AI',
    time: '1h ago',
    url: 'https://blog.google/technology/ai/'
  },
  {
    id: 'n2',
    title: 'New Workspace features to boost team productivity',
    source: 'The Keyword',
    category: 'Product',
    time: '4h ago',
    url: 'https://blog.google/products/workspace/'
  },
  {
    id: 'n3',
    title: 'Google Search: Enhancing results with generative AI snapshots',
    source: 'Search Labs',
    category: 'Product',
    time: '8h ago',
    url: 'https://blog.google/products/search/'
  },
  {
    id: 'n4',
    title: 'Android 15: Security and performance updates for Pixel',
    source: 'Android Dev Blog',
    category: 'Dev',
    time: '1d ago',
    url: 'https://android-developers.googleblog.com/'
  }
];

interface GGNewsMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GGNewsMenu: React.FC<GGNewsMenuProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-[110]" onClick={onClose} />
      <div className="absolute top-14 right-0 w-[380px] bg-m3-surface-container-high rounded-[28px] shadow-elevation-3 z-[120] overflow-hidden animate-fadeIn origin-top-right border border-m3-outline-variant/10">
        <div className="p-6 bg-m3-primary/5 border-b border-m3-outline-variant/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Newspaper className="w-5 h-5 text-m3-primary" />
            <h3 className="font-display font-medium text-m3-on-surface">GGnews Layer</h3>
          </div>
          <span className="text-[10px] font-bold bg-red-500 text-white px-2 py-0.5 rounded-full animate-pulse uppercase tracking-tighter">Live Feed</span>
        </div>

        <div className="max-h-[420px] overflow-y-auto custom-scrollbar">
          {GOOGLE_NEWS.map((news) => (
            <a
              key={news.id}
              href={news.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block p-5 hover:bg-m3-on-surface/5 transition-colors border-b border-m3-outline-variant/5 last:border-0 group"
            >
              <div className="flex items-center justify-between mb-2">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                  news.category === 'AI' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300' :
                  news.category === 'Dev' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300' :
                  'bg-m3-surface-container-highest text-m3-on-surface-variant'
                }`}>
                  {news.category}
                </span>
                <span className="text-[10px] text-m3-on-surface-variant/60 font-medium">{news.time}</span>
              </div>
              <h4 className="text-sm font-medium text-m3-on-surface group-hover:text-m3-primary transition-colors leading-snug mb-1">
                {news.title}
              </h4>
              <div className="flex items-center justify-between">
                <p className="text-[11px] text-m3-on-surface-variant/70">{news.source}</p>
                <ExternalLink className="w-3 h-3 text-m3-on-surface-variant/40 group-hover:text-m3-primary opacity-0 group-hover:opacity-100 transition-all" />
              </div>
            </a>
          ))}
        </div>

        <div className="p-4 bg-m3-surface-container-highest/30">
          <button 
            onClick={() => window.open('https://blog.google/', '_blank')}
            className="w-full py-3 rounded-full bg-m3-primary text-m3-on-primary text-xs font-bold flex items-center justify-center gap-2 hover:shadow-elevation-1 transition-all"
          >
            Ver todas no The Keyword
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </>
  );
};