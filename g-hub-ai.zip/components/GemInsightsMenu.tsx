import React, { useState, useEffect } from 'react';
// Corrected imports to include ArrowRight and removed unused ChevronRight
import { Wand2, Copy, Check, ExternalLink, Sparkles, Briefcase, User, ArrowRight, Loader2 } from 'lucide-react';
import { GemInsight } from '../types';
import { generateGemInsights } from '../services/geminiService';

interface GemInsightsMenuProps {
  isOpen: boolean;
  onClose: () => void;
  recentQueries: string[];
}

export const GemInsightsMenu: React.FC<GemInsightsMenuProps> = ({ isOpen, onClose, recentQueries }) => {
  const [insights, setInsights] = useState<GemInsight[]>([]);
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadInsights();
    }
  }, [isOpen]);

  const loadInsights = async () => {
    setLoading(true);
    const data = await generateGemInsights(recentQueries);
    setInsights(data);
    setLoading(false);
  };

  const handleCopy = (insight: GemInsight) => {
    navigator.clipboard.writeText(insight.instructions);
    setCopiedId(insight.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-[110]" onClick={onClose} />
      <div className="absolute top-14 right-0 w-[420px] bg-m3-surface-container-high rounded-[28px] shadow-elevation-3 z-[120] overflow-hidden animate-fadeIn origin-top-right border border-m3-outline-variant/10">
        <div className="p-6 bg-gradient-to-r from-purple-500/10 to-blue-500/10 border-b border-m3-outline-variant/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wand2 className="w-5 h-5 text-purple-500" />
            <h3 className="font-display font-medium text-m3-on-surface">Gem Architect</h3>
          </div>
          <button 
            onClick={loadInsights}
            disabled={loading}
            className="p-2 rounded-full hover:bg-m3-on-surface/5 transition-colors disabled:opacity-50"
          >
            <Loader2 className={`w-4 h-4 text-m3-on-surface-variant ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        <div className="max-h-[500px] overflow-y-auto custom-scrollbar p-4 space-y-4">
          {loading ? (
            <div className="py-20 flex flex-col items-center justify-center space-y-4">
              <Sparkles className="w-12 h-12 text-purple-400 animate-pulse" />
              <p className="text-sm text-m3-on-surface-variant animate-pulse font-medium">Analyzing your potential...</p>
            </div>
          ) : insights.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-sm text-m3-on-surface-variant">No Gem ideas yet. Try searching for tasks above!</p>
            </div>
          ) : (
            insights.map((gem) => (
              <div key={gem.id} className="p-4 rounded-[20px] bg-m3-surface-container-low border border-m3-outline-variant/5 hover:border-purple-500/30 transition-all group">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-300">
                      {gem.type === 'Professional' ? <Briefcase className="w-4 h-4" /> : <User className="w-4 h-4" />}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-m3-on-surface group-hover:text-purple-500 transition-colors">{gem.name}</h4>
                      <p className="text-[10px] uppercase font-bold text-m3-on-surface-variant/50 tracking-widest">{gem.type}</p>
                    </div>
                  </div>
                </div>
                
                <p className="text-xs text-m3-on-surface-variant mb-4 leading-relaxed">
                  {gem.purpose}
                </p>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCopy(gem)}
                    className="flex-1 flex items-center justify-center gap-2 py-2 rounded-full bg-m3-surface-container-highest text-[11px] font-bold text-m3-on-surface hover:bg-purple-500 hover:text-white transition-all active:scale-95"
                  >
                    {copiedId === gem.id ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedId === gem.id ? 'Instructions Copied!' : 'Copy Instructions'}
                  </button>
                  <a 
                    href="https://gemini.google.com/gems/view"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-full bg-m3-surface-container-highest text-m3-on-surface-variant hover:text-purple-500 transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="p-4 bg-m3-surface-container-highest/30 border-t border-m3-outline-variant/10">
          <p className="text-[10px] text-m3-on-surface-variant/70 text-center mb-3">
            Gems are custom AI agents you can build in Gemini to handle repetitive tasks.
          </p>
          <a 
            href="https://gemini.google.com/gems/view"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3 rounded-full bg-purple-600 text-white text-xs font-bold flex items-center justify-center gap-2 hover:bg-purple-700 hover:shadow-elevation-2 transition-all"
          >
            Open My Gems Dashboard
            <ArrowRight className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </>
  );
};