
import React, { useState, useEffect, useRef } from 'react';
import { GoogleApp, AppCategory } from '../types';
import { CATEGORY_DESCRIPTIONS } from '../constants';
import { generateAppIcon } from '../services/geminiService';
import { 
  Calendar, MessageCircle, Chrome, Users, FileText, HardDrive, Watch, 
  ClipboardList, Mail, Mic, GraduationCap, Wifi, TrendingUp, Heart, Plane, 
  Map, Newspaper, Cloud, CreditCard, Image, Play, Clapperboard, Headphones, 
  Search, ShoppingBag, Tv, Languages, Briefcase, Phone, Wallet, StickyNote, 
  Camera, Video, Ticket, BookOpen, Table, MonitorPlay, Car, Youtube, Music,
  LayoutGrid, LucideIcon, Zap, Box, Monitor, Code, Flame, Server, 
  Smartphone, Layers, Cpu, Brain, LineChart, Megaphone, BadgeDollarSign,
  Globe, Book, Shield, PenTool, Database, BarChart3, Binary, Palette,
  Beaker, Sparkles, Bot, Wand2, Type, Eye, ScrollText, Library, Dna, 
  Gamepad2, Pencil, BotMessageSquare, FileCode, Star, ChevronDown, Presentation,
  Gauge, Terminal, Package, Wrench, Lock, Cog, FileJson, MoreVertical, ExternalLink,
  Laptop, Cast, Home, Tablet, Speaker, KeyRound, LocateFixed, Pen, Braces, MessageSquare, 
  ImagePlus, Info, X, ArrowRight, Share2, Layers2, Activity, ShieldAlert, Key, 
  CloudLightning, DatabaseBackup, Network, Unplug, Workflow, Globe2,
  Tag, Microscope, Dumbbell, Rocket, Microscope as MicroscopeIcon, FileVideo,
  Database as DatabaseIcon, Layout, SearchCode, Settings2, PhoneCall, Image as ImageIcon,
  MessagesSquare, CarFront, HeartPulse, Wind, Moon, Orbit, DollarSign, PlaneTakeoff,
  Stethoscope, Microscope as MicroIcon, Building2, BarChart, Binary as BinaryIcon,
  SearchCheck, Store, Hotel, Music2, Scan, Trophy, Variable, FlaskConical, 
  RadioTower, Layers3, Fingerprint, DatabaseZap, Infinity, School, Target,
  Landmark, Award, ChevronUp, Plus, Loader2, Usb, Utensils, Radar, Music4,
  Clock, Ghost, PartyPopper, Scale, MousePointer2, Gift, Grid2X2, Lightbulb,
  Music3, Waves, Aperture, View, Leaf, Puzzle, Timer, Signal
} from 'lucide-react';

interface RippleData {
  x: number;
  y: number;
  size: number;
  id: number;
}

interface AppCardProps {
  app?: GoogleApp;
  isRecommended?: boolean;
  isLoading?: boolean;
  isActive?: boolean;
  onToggle?: () => void;
}

const iconMap: Record<string, LucideIcon> = {
  // Alphabet
  'waymo': CarFront,
  'verily': HeartPulse,
  'wing': Wind,
  'calico': Dna,
  'intrinsic': Cpu,
  'isomorphic': MicroIcon,
  'x_moonshot': Moon,
  'google_fiber': RadioTower,

  // AI & Labs (Specific High-Value Icons)
  'gemini': Sparkles,
  'google_ai_studio': Zap,
  'notebooklm': Bot,
  'veo': Video,
  'imagefx': ImagePlus,
  'musicfx': Music2,
  'mediapipe': Activity,
  'teachable_machine': Brain,
  'astra': BotMessageSquare,
  'textfx': PenTool,
  'illuminate': Headphones,
  'gentype': Type,
  'search_labs': FlaskConical,
  'chrome_music_lab': Music4,

  // Cloud & Dev
  'google_cloud': Server,
  'vertex_ai': Brain,
  'bigquery': DatabaseIcon,
  'spanner': DatabaseZap,
  'firebase': Flame,
  'cloud_run': CloudLightning,
  'flutter': Layers,
  'project_idx': Box,
  'tensorflow': Brain,
  'jax': BinaryIcon,
  'golang': Terminal,
  'colab': FileCode,
  'kaggle': Trophy,
  'looker': BarChart3,
  'anthos': Layers3,
  'apps_script': Braces,
  'android_studio': Smartphone,
  'adk': Usb,

  // Business
  'ads': Megaphone,
  'adsense': DollarSign,
  'admob': Smartphone,
  'analytics': LineChart,
  'search_console': SearchCheck,
  'merchant_center': Store,
  'tag_manager': Tag,
  'google_domains': Globe,

  // Workspace
  'gmail': Mail,
  'meet': Video,
  'chat': MessageCircle,
  'drive': HardDrive,
  'docs': FileText,
  'sheets': Table,
  'slides': Presentation,
  'forms': ClipboardList,
  'keep': StickyNote,
  'appsheet': Workflow,
  'google_vids': FileVideo,

  // Knowledge & Search
  'search': Search,
  'maps': Map,
  'earth': Globe2,
  'trends': TrendingUp,
  'scholar': Library,
  'patents': ScrollText,
  'books': Book,
  'arts_culture': Palette,
  'finance': Landmark,
  'flights': PlaneTakeoff,

  // Hardware & OS
  'android': Smartphone,
  'pixel': Smartphone,
  'chromeos': Monitor,
  'fitbit': Watch,
  'nest': Home,
  'wallet': Wallet,
  'photos': ImageIcon,
  'google_takeout': Box,

  // Entertainment
  'youtube': Youtube,
  'youtube_music': Music2,
  'google_tv': Tv,

  // Other Programs
  'grow_google': School,
  'skillshop': Award,
  'startup_school': Rocket
};

const categoryIconMap: Record<string, LucideIcon> = {
  [AppCategory.PRODUCTIVITY]: Zap,
  [AppCategory.COMMUNICATION]: MessageCircle,
  [AppCategory.ENTERTAINMENT]: Play,
  [AppCategory.UTILITY]: Box,
  [AppCategory.BUSINESS]: Briefcase,
  [AppCategory.KNOWLEDGE]: BookOpen,
  [AppCategory.HARDWARE]: Monitor,
  [AppCategory.DEVELOPER]: Code,
  [AppCategory.LABS]: FlaskConical,
  [AppCategory.ALPHABET]: Orbit,
  [AppCategory.OTHER]: LayoutGrid
};

export const AppCard: React.FC<AppCardProps> = ({ 
  app, 
  isRecommended, 
  isLoading, 
  isActive = false, 
  onToggle 
}) => {
  const [isFavorite, setIsFavorite] = useState(false);
  const [ripples, setRipples] = useState<RippleData[]>([]);
  const [aiIcon, setAiIcon] = useState<string | null>(null);
  const [isGeneratingIcon, setIsGeneratingIcon] = useState(false);
  const [isDescriptionExpanded, setIsDescriptionExpanded] = useState(false);

  useEffect(() => {
    if (app?.id) {
      const favorites = JSON.parse(localStorage.getItem('ghub_favorites') || '[]');
      setIsFavorite(favorites.includes(app.id));

      // AI Icon Generation Logic
      // If we don't have a hardcoded icon for this specific app ID, and no heuristic matches
      if (!iconMap[app.id] && !getHeuristicIcon(app)) {
        const cachedIcon = localStorage.getItem(`ai_icon_${app.id}`);
        if (cachedIcon) {
          setAiIcon(cachedIcon);
        } else {
          handleGenerateIcon();
        }
      }
    }
  }, [app?.id]);

  const handleGenerateIcon = async () => {
    if (!app) return;
    setIsGeneratingIcon(true);
    try {
      const generated = await generateAppIcon(app.name, app.description);
      if (generated) {
        setAiIcon(generated);
        localStorage.setItem(`ai_icon_${app.id}`, generated);
      }
    } catch (e) {
      console.error("Failed to generate AI icon");
    } finally {
      setIsGeneratingIcon(false);
    }
  };

  const toggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault(); e.stopPropagation();
    if (!app) return;
    const favorites = JSON.parse(localStorage.getItem('ghub_favorites') || '[]');
    let newFavorites;
    if (favorites.includes(app.id)) {
      newFavorites = favorites.filter((id: string) => id !== app.id);
      setIsFavorite(false);
    } else {
      newFavorites = [...favorites, app.id];
      setIsFavorite(true);
    }
    localStorage.setItem('ghub_favorites', JSON.stringify(newFavorites));
  };

  const addRipple = (e: React.MouseEvent) => {
    const card = e.currentTarget;
    const rect = card.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 2.5;
    const x = e.clientX - rect.left - size / 2;
    const y = e.clientY - rect.top - size / 2;
    const newRipple: RippleData = { x, y, size, id: Date.now() };
    setRipples(prev => [...prev, newRipple]);
    setTimeout(() => {
      setRipples(prev => prev.filter(r => r.id !== newRipple.id));
    }, 600);
  };

  const handleClick = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('.btn-action')) return;
    // Don't trigger main card toggle if text is expanded and we clicked the text (handled via stopPropagation below)
    addRipple(e);
    if (onToggle) onToggle();
  };

  const handleDescriptionClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsDescriptionExpanded(!isDescriptionExpanded);
  };

  const getHeuristicIcon = (currentApp: GoogleApp): LucideIcon | null => {
    const lowerName = currentApp.name.toLowerCase();
    const lowerDesc = currentApp.description.toLowerCase();
    const lowerId = currentApp.id.toLowerCase();

    // Chrome Music Lab & Audio
    if (lowerId.startsWith('cml_') || lowerName.includes('music') || lowerName.includes('sound') || lowerName.includes('rhythm') || lowerName.includes('song')) return Music3;
    if (lowerName.includes('voice') || lowerName.includes('speech')) return Mic;
    if (lowerName.includes('opera') || lowerName.includes('choir')) return Mic;
    if (lowerName.includes('radio') || lowerName.includes('podcast')) return RadioTower;
    if (lowerName.includes('frequency') || lowerName.includes('wave')) return Waves;
    
    // Visuals & Art
    if (lowerName.includes('draw') || lowerName.includes('paint') || lowerName.includes('sketch') || lowerName.includes('art')) return Palette;
    if (lowerName.includes('color') || lowerName.includes('palette')) return Palette;
    if (lowerName.includes('camera') || lowerName.includes('lens')) return Camera;
    if (lowerName.includes('photo') || lowerName.includes('image')) return Image;
    if (lowerName.includes('visual') || lowerName.includes('sight')) return Eye;
    
    // AR/VR/3D
    if (lowerName.includes('ar ') || lowerName.includes('vr ') || lowerName.includes('3d') || lowerName.includes('dimension') || lowerId.includes('ar_') || lowerName.includes('measure')) return Box;
    if (lowerName.includes('sodar') || lowerName.includes('radar')) return Radar;
    if (lowerName.includes('tunnel') || lowerName.includes('floom')) return LocateFixed;
    if (lowerName.includes('sprayscape')) return Camera;
    
    // AI/ML
    if (lowerName.includes('ai') || lowerName.includes('learning') || lowerName.includes('neural')) return Brain;
    if (lowerName.includes('data') || lowerName.includes('chart')) return BarChart3;
    
    // Games
    if (lowerName.includes('game') || lowerName.includes('play')) return Gamepad2;
    if (lowerName.includes('puzzle') || lowerName.includes('quiz')) return Puzzle;
    if (lowerName.includes('lines of play')) return Grid2X2;

    // Time & Weather
    if (lowerName.includes('clock') || lowerName.includes('time')) return Clock;
    if (lowerName.includes('weather') || lowerName.includes('climate')) return Leaf;
    if (lowerName.includes('signal') || lowerName.includes('wifi')) return Signal;

    // Science & Education
    if (lowerName.includes('science') || lowerName.includes('lab') || lowerName.includes('chemistry')) return FlaskConical;
    if (lowerName.includes('language') || lowerName.includes('translate')) return Languages;
    if (lowerName.includes('hieroglyphs') || lowerName.includes('decode')) return ScrollText;

    return null;
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-between p-6 rounded-[12px] bg-m3-surface-container-low h-[240px] animate-pulse">
        <div className="w-16 h-16 rounded-[12px] bg-m3-surface-container-highest mb-4"></div>
        <div className="w-full space-y-3">
          <div className="w-3/4 h-5 bg-m3-surface-container-highest rounded-full mx-auto"></div>
          <div className="w-full h-3 bg-m3-surface-container-highest rounded-full"></div>
        </div>
      </div>
    );
  }

  if (!app) return null;

  const renderIcon = (size: 'small' | 'large') => {
    const dimensions = size === 'large' ? 'w-10 h-10 md:w-14 md:h-14' : 'w-10 h-10';
    
    // Priority 1: Mapped Static Icon
    if (iconMap[app.id]) {
      const IconComponent = iconMap[app.id];
      return <IconComponent className={dimensions} strokeWidth={1.5} />;
    }

    // Priority 2: Heuristic Icon (Regex/Keyword matching)
    const HeuristicIcon = getHeuristicIcon(app);
    if (HeuristicIcon) {
       return <HeuristicIcon className={dimensions} strokeWidth={1.5} />;
    }

    // Priority 3: Loading Animation
    if (isGeneratingIcon) {
      return (
        <div className="relative flex items-center justify-center">
          <Sparkles className={`${dimensions} text-white animate-pulse opacity-50`} strokeWidth={1.5} />
          <Loader2 className="absolute w-5 h-5 text-white/40 animate-spin" />
        </div>
      );
    }

    // Priority 4: Generated AI Icon
    if (aiIcon) {
      return (
        <img 
          src={aiIcon} 
          alt={`${app.name} icon`} 
          className={`${dimensions} object-cover rounded-[12px] md:rounded-[16px] shadow-sm transition-opacity duration-700`} 
          onLoad={(e) => (e.currentTarget.style.opacity = '1')}
          style={{ opacity: 0 }}
        />
      );
    }

    // Priority 5: Category Fallback or Final Fallback
    const FallbackIcon = categoryIconMap[app.category] || LayoutGrid;
    return <FallbackIcon className={dimensions} strokeWidth={1.5} />;
  };

  if (isActive) {
    return (
      <div 
        onClick={handleClick}
        className="app-card-container relative w-full h-full min-h-[540px] flex flex-col md:flex-row overflow-hidden rounded-[12px] bg-m3-surface-container-high shadow-elevation-3 cursor-default transition-all duration-500 ease-emphasized border border-m3-outline-variant/10 group/active"
      >
        <div className="absolute inset-0 pointer-events-none z-[1] overflow-hidden">
          {ripples.map((ripple) => (
            <span key={ripple.id} className="absolute rounded-full animate-ripple" style={{ top: ripple.y, left: ripple.x, width: ripple.size, height: ripple.size, backgroundColor: `${app.color}15` }} />
          ))}
        </div>
        <button onClick={(e) => { e.stopPropagation(); if(onToggle) onToggle(); }} className="absolute top-6 right-6 z-[10] p-3 rounded-full bg-m3-surface-container-highest/60 backdrop-blur-sm hover:bg-m3-surface-container-highest text-m3-on-surface transition-all active:scale-95 shadow-sm">
          <ChevronUp className="w-6 h-6" />
        </button>
        
        <div className="w-full md:w-2/5 relative overflow-hidden flex flex-col justify-end p-10 md:p-12 z-[2]" style={{ backgroundColor: `${app.color}08` }}>
           <div className="absolute top-[-50%] left-[-50%] w-[200%] h-[200%] rounded-full opacity-[0.08] blur-[140px]" style={{ backgroundColor: app.color }}></div>
           <div className="relative z-10 animate-slideUpFade">
              <div 
                className="w-20 h-20 md:w-28 md:h-28 rounded-[12px] md:rounded-[16px] flex items-center justify-center text-white shadow-elevation-2 mb-10 transition-transform duration-700 group-hover/active:scale-105 overflow-hidden" 
                style={{ backgroundColor: app.color }}
              >
                {renderIcon('large')}
              </div>
              <div className="inline-flex items-center px-5 py-2 rounded-full text-[12px] font-bold uppercase tracking-[0.15em] bg-m3-surface-container-highest/50 backdrop-blur-md text-m3-on-surface-variant mb-6 border border-m3-outline-variant/20 shadow-sm">
                 {app.category}
              </div>
              <h2 className="text-4xl md:text-6xl font-display font-medium text-m3-on-surface leading-tight tracking-tight">
                {app.name}
              </h2>
           </div>
        </div>

        <div className="w-full md:w-3/5 p-10 md:p-14 flex flex-col justify-between bg-m3-surface-container-high relative z-[2] border-t md:border-t-0 md:border-l border-m3-outline-variant/20">
           <div className="space-y-12 overflow-y-auto custom-scrollbar pr-6">
              <div className="animate-slideUpFade" style={{ animationDelay: '0.1s' }}>
                <div className="flex items-center gap-3 mb-5 text-m3-primary/80">
                   <Info className="w-6 h-6" />
                   <h3 className="text-[12px] font-bold uppercase tracking-[0.25em]">Ecosystem Context</h3>
                </div>
                <p className="text-m3-on-surface text-2xl leading-relaxed font-light">{CATEGORY_DESCRIPTIONS[app.category]}</p>
              </div>
              
              <div className="w-full h-px bg-m3-outline-variant/10"></div>
              
              <div className="animate-slideUpFade" style={{ animationDelay: '0.2s' }}>
                 <h3 className="text-sm font-bold text-m3-on-surface/40 mb-4 uppercase tracking-[0.25em]">Solution Blueprint</h3>
                 <p className="text-m3-on-surface-variant text-xl leading-relaxed font-normal">{app.description}</p>
              </div>
           </div>

           <div className="mt-14 pt-8 flex flex-col sm:flex-row items-center justify-between gap-8 animate-slideUpFade" style={{ animationDelay: '0.3s' }}>
              <button onClick={toggleFavorite} className="btn-action flex items-center gap-4 text-base font-medium text-m3-on-surface-variant hover:text-m3-primary transition-all px-8 py-4 rounded-full hover:bg-m3-primary/5 active:scale-95 group/fav">
                 <Star className={`w-6 h-6 transition-all duration-500 ${isFavorite ? 'text-amber-400 fill-amber-400 scale-110 rotate-[360deg] shadow-sm' : 'group-hover/fav:scale-110'}`} />
                 <span>{isFavorite ? 'In Favorites' : 'Save for Later'}</span>
              </button>
              <a href={app.url} target="_blank" rel="noopener noreferrer" className="btn-action w-full sm:w-auto flex items-center justify-center gap-4 bg-m3-primary text-m3-on-primary px-12 py-5 rounded-full font-bold text-lg shadow-elevation-1 hover:shadow-elevation-2 hover:scale-[1.03] active:scale-95 transition-all duration-500 group/link">
                <span>Go to Service</span>
                <ArrowRight className="w-6 h-6 group-hover/link:translate-x-2 transition-transform" />
              </a>
           </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      onClick={handleClick}
      className={`
        app-card-container group relative flex flex-col items-center p-7 rounded-[12px] overflow-hidden cursor-pointer
        transition-all duration-500 ease-emphasized
        bg-m3-surface-container-low shadow-elevation-1 
        hover:shadow-elevation-2 hover:bg-m3-surface-container
        min-h-[280px] h-full border border-m3-outline-variant/5 hover:border-m3-outline-variant/20
        ${isRecommended ? 'bg-m3-primary-container/10 border-m3-primary/10 ring-1 ring-m3-primary/10' : ''}
      `}
    >
      <div className="absolute inset-0 pointer-events-none z-[1] overflow-hidden">
        {ripples.map((ripple) => (
          <span key={ripple.id} className="absolute rounded-full animate-ripple" style={{ top: ripple.y, left: ripple.x, width: ripple.size, height: ripple.size, backgroundColor: `${app.color}20` }} />
        ))}
      </div>

      <div 
        className="w-20 h-20 rounded-[12px] flex items-center justify-center text-white mb-8 shadow-elevation-1 relative overflow-hidden z-[2]" 
        style={{ backgroundColor: app.color }}
      >
        <div className="absolute inset-0 bg-gradient-to-tr from-black/20 via-transparent to-white/30 opacity-60 transition-opacity group-hover:opacity-30"></div>
        <div className="relative z-10 transition-transform duration-700 group-hover:scale-110 group-hover:rotate-6">
          {renderIcon('small')}
        </div>
      </div>

      <div className="text-center relative w-full flex flex-col items-center flex-grow z-[2]">
        <h3 className="font-display font-medium text-m3-on-surface text-lg leading-tight mb-4 px-2 group-hover:text-m3-primary transition-colors duration-300 tracking-tight pointer-events-none">
          {app.name}
        </h3>
        <div className="relative w-full z-10">
          <p 
            onClick={handleDescriptionClick}
            className={`
              text-[13px] text-m3-on-surface-variant/70 leading-relaxed text-center px-1 
              transition-all duration-500 group-hover:text-m3-on-surface-variant
              cursor-pointer hover:bg-m3-on-surface/5 rounded-lg py-1
              ${isDescriptionExpanded ? 'line-clamp-none' : 'line-clamp-3'}
            `}
            title="Click to expand description"
          >
            {app.description}
          </p>
          <div className={`mt-4 flex items-center justify-center gap-1.5 opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-500 pointer-events-none ${isDescriptionExpanded ? 'hidden' : ''}`}>
             <span className="text-[11px] font-bold text-m3-primary/80 uppercase tracking-widest">Learn More</span>
             <Plus className="w-3.5 h-3.5 text-m3-primary/80" />
          </div>
        </div>
      </div>

      {isRecommended && (
        <div className="absolute top-4 right-4 z-[3]">
          <div className="bg-m3-primary text-m3-on-primary p-2 rounded-full shadow-elevation-1 animate-pulse">
             <Sparkles className="w-4 h-4" />
          </div>
        </div>
      )}
    </div>
  );
};
