import React, { useEffect, useState } from 'react';

interface IntroAnimationProps {
  onComplete: () => void;
}

export const IntroAnimation: React.FC<IntroAnimationProps> = ({ onComplete }) => {
  const [phase, setPhase] = useState<'spin' | 'reveal' | 'fade'>('spin');

  useEffect(() => {
    // Start with a spin phase
    const spinTimer = setTimeout(() => {
      setPhase('reveal');
    }, 1400);

    // After reveal, hold for a moment then fade
    const revealTimer = setTimeout(() => {
      setPhase('fade');
      // Complete the logical lifecycle slightly before the actual overlay disappears for smoothness
      setTimeout(onComplete, 400); 
    }, 3200);

    return () => {
      clearTimeout(spinTimer);
      clearTimeout(revealTimer);
    };
  }, [onComplete]);

  // Google G SVG Paths (Colored)
  const gPaths = (
    <g>
       <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
       <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
       <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
       <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
    </g>
  );

  return (
    <div 
      className={`fixed inset-0 z-[1000] flex items-center justify-center bg-m3-surface transition-all duration-1000 ease-in-out ${phase === 'fade' ? 'opacity-0 scale-105 pointer-events-none' : 'opacity-100 scale-100'}`}
    >
      <div className="flex items-center justify-center relative scale-110 sm:scale-125">
        {/* The G Logo - Hero sized */}
        <div className={`relative w-[64px] sm:w-[92px] h-[64px] sm:h-[92px] transition-transform duration-1000 ease-in-out ${phase === 'spin' ? 'animate-spin-cinematic' : 'transform rotate-0'}`}>
           <svg viewBox="0 0 48 48" className="w-full h-full block">
              {gPaths}
           </svg>
        </div>

        {/* The revealing Text part: "-Hub AI" */}
        <div 
           className={`overflow-hidden flex items-baseline whitespace-nowrap transition-all duration-1000 ease-[cubic-bezier(0.2,0,0,1)] ${phase !== 'spin' ? 'max-w-[1000px] opacity-100 ml-2 sm:ml-4' : 'max-w-0 opacity-0 ml-0'}`}
        >
          <div className="flex items-baseline w-max">
            <span className="font-display font-medium text-[64px] sm:text-[92px] leading-none tracking-tight flex items-baseline">
               <span className="text-m3-on-surface mx-[2px]">-</span>
               <span className="text-[#EA4335]">H</span>
               <span className="text-[#FBBC05]">u</span>
               <span className="text-[#34A853]">b</span>
            </span>
            <span className="font-display text-m3-on-surface-variant font-normal tracking-normal ml-3 sm:ml-5 text-[52px] sm:text-[76px] leading-none pr-1">
              AI
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};