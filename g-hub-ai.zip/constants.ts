

import { AppCategory, GoogleApp } from './types';

export const API_DOCS_LINKS = [
  { name: 'Gemini API', url: 'https://ai.google.dev/docs' },
  { name: 'Google Cloud APIs', url: 'https://cloud.google.com/apis' },
  { name: 'Alphabet Investor', url: 'https://abc.xyz/investor/' },
  { name: 'Vertex AI', url: 'https://cloud.google.com/vertex-ai/docs' },
  { name: 'Firebase Docs', url: 'https://firebase.google.com/docs' }
];

export const FEATURED_APP_IDS = [
  'gemini', 'waymo', 'vertex_ai', 'veo', 'flutter', 'notebooklm', 'google_cloud', 'android', 'ads', 'firebase', 'bigquery', 'chrome_music_lab', 'quick_draw', 'blob_opera'
];

export const CATEGORY_DESCRIPTIONS: Record<string, string> = {
  [AppCategory.PRODUCTIVITY]: "Advanced tools for enterprise collaboration, document engineering, and professional organization.",
  [AppCategory.COMMUNICATION]: "Omnichannel communication frameworks, consumer messaging platforms, and wireless services.",
  [AppCategory.ENTERTAINMENT]: "Global content delivery networks and immersive digital entertainment experiences.",
  [AppCategory.UTILITY]: "Critical system utilities, security protocols, and daily digital maintenance tools.",
  [AppCategory.BUSINESS]: "Market intelligence, ad-tech stacks, and enterprise-scale analytics solutions.",
  [AppCategory.KNOWLEDGE]: "Global information indexing, research repositories, and educational frameworks.",
  [AppCategory.HARDWARE]: "Silicon-integrated devices and ecosystem-optimized hardware platforms.",
  [AppCategory.DEVELOPER]: "Comprehensive SDKs, cloud infrastructure, and deployment pipelines for modern engineering.",
  [AppCategory.LABS]: "Bleeding edge Generative AI experiments, Chrome experiments, and early-stage research breakthroughs.",
  [AppCategory.ALPHABET]: "Alphabet's independent 'Other Bets' exploring the future of health, robotics, and logistics.",
  [AppCategory.OTHER]: "Ecosystem-wide programs, training initiatives, and community support."
};

// --- EXPERIMENT COLLECTIONS ---

const CHROME_MUSIC_LAB: GoogleApp[] = [
  { id: 'cml_song_maker', name: 'Song Maker', url: 'https://musiclab.chromeexperiments.com/Song-Maker/', category: AppCategory.LABS, color: '#F4B400', description: 'Make and share your own songs.' },
  { id: 'cml_rhythm', name: 'Rhythm', url: 'https://musiclab.chromeexperiments.com/Rhythm/', category: AppCategory.LABS, color: '#EA4335', description: 'Play with rhythm using cute characters.' },
  { id: 'cml_spectrogram', name: 'Spectrogram', url: 'https://musiclab.chromeexperiments.com/Spectrogram/', category: AppCategory.LABS, color: '#34A853', description: 'See the sound of your voice or other sounds.' },
  { id: 'cml_chords', name: 'Chords', url: 'https://musiclab.chromeexperiments.com/Chords/', category: AppCategory.LABS, color: '#4285F4', description: 'Learn about major and minor chords.' },
  { id: 'cml_sound_waves', name: 'Sound Waves', url: 'https://musiclab.chromeexperiments.com/Sound-Waves/', category: AppCategory.LABS, color: '#4285F4', description: 'Visualize how sound waves travel.' },
  { id: 'cml_arpeggios', name: 'Arpeggios', url: 'https://musiclab.chromeexperiments.com/Arpeggios/', category: AppCategory.LABS, color: '#F4B400', description: 'Play arpeggios in different patterns.' },
  { id: 'cml_kandinsky', name: 'Kandinsky', url: 'https://musiclab.chromeexperiments.com/Kandinsky/', category: AppCategory.LABS, color: '#EA4335', description: 'Turn your drawings into sound.' },
  { id: 'cml_melody_maker', name: 'Melody Maker', url: 'https://musiclab.chromeexperiments.com/Melody-Maker/', category: AppCategory.LABS, color: '#34A853', description: 'Create simple melodies with a grid.' },
  { id: 'cml_voice_spinner', name: 'Voice Spinner', url: 'https://musiclab.chromeexperiments.com/Voice-Spinner/', category: AppCategory.LABS, color: '#4285F4', description: 'Spin your voice fast, slow, or backward.' },
  { id: 'cml_harmonics', name: 'Harmonics', url: 'https://musiclab.chromeexperiments.com/Harmonics/', category: AppCategory.LABS, color: '#F4B400', description: 'Explore the harmonic series.' },
  { id: 'cml_piano_roll', name: 'Piano Roll', url: 'https://musiclab.chromeexperiments.com/Piano-Roll/', category: AppCategory.LABS, color: '#EA4335', description: 'Watch music notes scroll by like a player piano.' },
  { id: 'cml_oscillators', name: 'Oscillators', url: 'https://musiclab.chromeexperiments.com/Oscillators/', category: AppCategory.LABS, color: '#34A853', description: 'Hear different types of oscillators.' },
  { id: 'cml_strings', name: 'Strings', url: 'https://musiclab.chromeexperiments.com/Strings/', category: AppCategory.LABS, color: '#4285F4', description: 'Explore the physics of string resonance.' },
];

const AI_EXPERIMENTS: GoogleApp[] = [
  { id: 'quick_draw', name: 'Quick, Draw!', url: 'https://quickdraw.withgoogle.com/', category: AppCategory.LABS, color: '#4285F4', description: 'Can a neural network learn to recognize your doodling?' },
  { id: 'autodraw', name: 'AutoDraw', url: 'https://www.autodraw.com/', category: AppCategory.LABS, color: '#0F9D58', description: 'Fast drawing for everyone. Pair machine learning with drawings from talented artists.' },
  { id: 'teachable_machine', name: 'Teachable Machine', url: 'https://teachablemachine.withgoogle.com/', category: AppCategory.LABS, color: '#FBBC05', description: 'Fast, easy way to create machine learning models for sites and apps.' },
  { id: 'verse_by_verse', name: 'Verse by Verse', url: 'https://sites.research.google/versebyverse/', category: AppCategory.LABS, color: '#4285F4', description: 'An experimental AI-powered muse that helps you compose poetry.' },
  { id: 'freddie_meter', name: 'FreddieMeter', url: 'https://freddiemeter.withyoutube.com/', category: AppCategory.LABS, color: '#FFCE00', description: 'Find out how closely your singing matches Freddie Mercury\'s voice.' },
  { id: 'scroobly', name: 'Scroobly', url: 'https://artsexperiments.withgoogle.com/scroobly/', category: AppCategory.LABS, color: '#9C27B0', description: 'Use your camera to animate doodles with your face and body.' },
  { id: 'tone_transfer', name: 'Tone Transfer', url: 'https://sites.research.google/tonetransfer', category: AppCategory.LABS, color: '#EA4335', description: 'Transform everyday sounds into musical instruments.' },
  { id: 'thing_translator', name: 'Thing Translator', url: 'https://experiments.withgoogle.com/thing-translator', category: AppCategory.LABS, color: '#FBBC05', description: 'Take a picture of something to hear how to say it in a different language.' },
  { id: 'say_what_you_see', name: 'Say What You See', url: 'https://artsandculture.google.com/experiment/say-what-you-see/jwG3m7wQ5le2gw', category: AppCategory.LABS, color: '#34A853', description: 'Learn to prompt by describing images in this AI game.' },
  { id: 'visual_blocks', name: 'Visual Blocks', url: 'https://visualblocks.withgoogle.com/', category: AppCategory.LABS, color: '#4285F4', description: 'No-code ML for creative coding and prototyping.' },
  { id: 'infinite_drum_machine', name: 'Infinite Drum Machine', url: 'https://experiments.withgoogle.com/ai/drum-machine', category: AppCategory.LABS, color: '#4285F4', description: 'Thousands of everyday sounds organized by similarity.' },
  { id: 'semantics_ris', name: 'Semantris', url: 'https://research.google.com/semantris/', category: AppCategory.LABS, color: '#4285F4', description: 'Word association games powered by semantic search.' },
  { id: 'giorgio_cam', name: 'Giorgio Cam', url: 'https://experiments.withgoogle.com/giorgio-cam', category: AppCategory.LABS, color: '#EA4335', description: 'Take a picture and hear music made from what the computer sees.' },
  { id: 'bird_sounds', name: 'Bird Sounds', url: 'https://experiments.withgoogle.com/bird-sounds', category: AppCategory.LABS, color: '#4285F4', description: 'Thousands of bird sounds visualized using machine learning.' },
  { id: 'shadow_art', name: 'Shadow Art', url: 'https://artsexperiments.withgoogle.com/shadowart/', category: AppCategory.LABS, color: '#34A853', description: 'Use your hands to make shadow puppets in front of your camera.' },
  { id: 'move_mirror', name: 'Move Mirror', url: 'https://experiments.withgoogle.com/move-mirror', category: AppCategory.LABS, color: '#9C27B0', description: 'Explore images just by moving around in front of your camera.' },
  { id: 'body_synth', name: 'Body Synth', url: 'https://experiments.withgoogle.com/body-synth', category: AppCategory.LABS, color: '#9C27B0', description: 'Play music using your body movement and ML.' },
  { id: 'euphonia', name: 'Project Euphonia', url: 'https://sites.research.google/euphonia/about/', category: AppCategory.LABS, color: '#4285F4', description: 'Helping people with non-standard speech be understood.' },
  { id: 'interview_warmup', name: 'Interview Warmup', url: 'https://grow.google/certificates/interview-warmup/', category: AppCategory.LABS, color: '#4285F4', description: 'Practice answering questions to get more confident with your job interview.' },
];

const AR_VR_EXPERIMENTS: GoogleApp[] = [
  { id: 'sodar', name: 'Sodar', url: 'https://sodar.withgoogle.com/', category: AppCategory.LABS, color: '#4285F4', description: 'Use WebXR to visualize social distancing guidelines in your environment.' },
  { id: 'floom', name: 'Floom', url: 'https://floom.withgoogle.com/', category: AppCategory.LABS, color: '#34A853', description: 'Tunnel through the earth with WebXR to see what is on the other side.' },
  { id: 'measure_up', name: 'Measure Up', url: 'https://measureup.withgoogle.com/', category: AppCategory.LABS, color: '#FBBC05', description: 'Calculate the length, area, and volume of things in the real world using WebXR.' },
  { id: 'pictures_of_year', name: 'Pictures of the Year', url: 'https://experiments.withgoogle.com/pictures-of-the-year', category: AppCategory.LABS, color: '#000000', description: 'An AI experiment exploring the most searched images of the year.' },
  { id: 'ar_chemistry', name: 'AR Chemistry', url: 'https://artsexperiments.withgoogle.com/ar-chemistry/', category: AppCategory.LABS, color: '#EA4335', description: 'Explore molecules in 3D right in your browser.' },
  { id: 'big_bang_ar', name: 'Big Bang AR', url: 'https://artsandculture.google.com/project/big-bang-ar', category: AppCategory.LABS, color: '#000000', description: 'Join Tilda Swinton and CERN scientists on an interactive journey through the birth of the universe.' },
  { id: 'notable_women', name: 'Notable Women', url: 'https://notablewomen.withgoogle.com/', category: AppCategory.LABS, color: '#4285F4', description: 'See 100 historic American women where they’ve historically been left out: U.S. currency.' },
  { id: 'just_a_line', name: 'Just a Line', url: 'https://experiments.withgoogle.com/just-a-line', category: AppCategory.LABS, color: '#F4B400', description: 'Make simple drawings in augmented reality, then share your creation with a short video.' },
  { id: 'lines_of_play', name: 'Lines of Play', url: 'https://experiments.withgoogle.com/lines-of-play', category: AppCategory.LABS, color: '#34A853', description: 'Visualize dominos in AR.' },
];

const ARTS_CULTURE_EXPERIMENTS: GoogleApp[] = [
  { id: 'blob_opera', name: 'Blob Opera', url: 'https://artsandculture.google.com/experiment/blob-opera/AAHWrq360NcGbw', category: AppCategory.LABS, color: '#EA4335', description: 'Create your own opera with machine learning.' },
  { id: 'art_transfer', name: 'Art Transfer', url: 'https://artsandculture.google.com/camera/art-transfer', category: AppCategory.LABS, color: '#9C27B0', description: 'Transform your photos with characteristics of well-known paintings.' },
  { id: 'art_selfie', name: 'Art Selfie', url: 'https://artsandculture.google.com/camera/art-selfie', category: AppCategory.LABS, color: '#4285F4', description: 'Discover your doppelgänger in a work of art.' },
  { id: 'color_palette', name: 'Color Palette', url: 'https://artsexperiments.withgoogle.com/art-palette/', category: AppCategory.LABS, color: '#FBBC05', description: 'Find artworks that match your chosen color palette.' },
  { id: 'puzzle_party', name: 'Puzzle Party', url: 'https://artsandculture.google.com/experiment/puzzle-party/EwG5wX6g0GqO9Q', category: AppCategory.LABS, color: '#34A853', description: 'Solve jigsaw puzzles of famous artworks together.' },
  { id: 'crosswords', name: 'Cultural Crosswords', url: 'https://artsandculture.google.com/experiment/cultural-crosswords/AAHWrq360NcGbw', category: AppCategory.LABS, color: '#4285F4', description: 'Test your knowledge of art and culture with crossword puzzles.' },
  { id: 'woolaroo', name: 'Woolaroo', url: 'https://artsandculture.google.com/experiment/woolaroo/6gHCmO_d9nQ6hQ', category: AppCategory.LABS, color: '#EA4335', description: 'Explore endangered languages with machine learning.' },
  { id: 'fabricius', name: 'Fabricius', url: 'https://artsexperiments.withgoogle.com/fabricius/', category: AppCategory.LABS, color: '#F4B400', description: 'Decode ancient Egyptian hieroglyphs with machine learning.' },
  { id: 'climate_card', name: 'Climate Card', url: 'https://artsexperiments.withgoogle.com/climate-card/', category: AppCategory.LABS, color: '#34A853', description: 'Send a postcard from a future impacted by climate change.' },
];

const ANDROID_EXPERIMENTS: GoogleApp[] = [
  { id: 'unlock_clock', name: 'Unlock Clock', url: 'https://experiments.withgoogle.com/unlock-clock', category: AppCategory.LABS, color: '#000000', description: 'A wallpaper that counts how many times you unlock your phone in a day.' },
  { id: 'post_box', name: 'Post Box', url: 'https://experiments.withgoogle.com/post-box', category: AppCategory.LABS, color: '#EA4335', description: 'A Digital Wellbeing experiment that bundles your notifications.' },
  { id: 'morph', name: 'Morph', url: 'https://experiments.withgoogle.com/morph', category: AppCategory.LABS, color: '#4285F4', description: 'An Android launcher that shows you the right apps at the right time.' },
  { id: 'paper_signals', name: 'Paper Signals', url: 'https://experiments.withgoogle.com/paper-signals', category: AppCategory.LABS, color: '#34A853', description: 'Build a paper object that tracks things like weather or Bitcoin.' },
  { id: 'sprayscape', name: 'Sprayscape', url: 'https://experiments.withgoogle.com/sprayscape', category: AppCategory.LABS, color: '#9C27B0', description: 'A perfectly imperfect VR camera.' },
  { id: 'science_journal', name: 'Science Journal', url: 'https://experiments.withgoogle.com/science-journal', category: AppCategory.LABS, color: '#4285F4', description: 'Turn your phone into a pocket science laboratory.' },
];

export const GOOGLE_APPS: GoogleApp[] = [
  // --- ALPHABET (OTHER BETS) ---
  { id: 'waymo', name: 'Waymo', url: 'https://waymo.com/', category: AppCategory.ALPHABET, color: '#00D1FF', description: 'Autonomous driving technology company building the world’s most experienced driver.' },
  { id: 'verily', name: 'Verily', url: 'https://verily.com/', category: AppCategory.ALPHABET, color: '#484848', description: 'Precision health company using data to improve human health outcomes.' },
  { id: 'wing', name: 'Wing', url: 'https://wing.com/', category: AppCategory.ALPHABET, color: '#FFD700', description: 'Autonomous drone delivery service and unmanned aircraft traffic management.' },
  { id: 'calico', name: 'Calico', url: 'https://www.calicolabs.com/', category: AppCategory.ALPHABET, color: '#F48220', description: 'R&D company focused on understanding the biology that controls lifespan.' },
  { id: 'intrinsic', name: 'Intrinsic', url: 'https://intrinsic.ai/', category: AppCategory.ALPHABET, color: '#00AC47', description: 'Software company making industrial robotics more accessible and usable.' },
  { id: 'isomorphic', name: 'Isomorphic Labs', url: 'https://www.isomorphiclabs.com/', category: AppCategory.ALPHABET, color: '#9C27B0', description: 'AI-first drug discovery company building on the success of AlphaFold.' },
  { id: 'x_moonshot', name: 'X (The Moonshot Factory)', url: 'https://x.company/', category: AppCategory.ALPHABET, color: '#F4B400', description: 'Alphabet\'s invention factory tackling the world\'s hardest problems.' },
  { id: 'google_fiber', name: 'Google Fiber', url: 'https://fiber.google.com/', category: AppCategory.ALPHABET, color: '#4285F4', description: 'High-speed fiber-optic internet service.' },

  // --- AI, LABS & EXPERIMENTAL (Major Platforms) ---
  { id: 'gemini', name: 'Gemini', url: 'https://gemini.google.com', category: AppCategory.LABS, color: '#8E24AA', description: 'Multimodal AI for complex reasoning, coding, and creative collaboration.' },
  { id: 'google_ai_studio', name: 'Google AI Studio', url: 'https://aistudio.google.com/', category: AppCategory.LABS, color: '#8E24AA', description: 'The fastest way to start building with Gemini models.' },
  { id: 'notebooklm', name: 'NotebookLM', url: 'https://notebooklm.google.com', category: AppCategory.LABS, color: '#8E24AA', description: 'AI-first research assistant grounded in your own documents.' },
  { id: 'veo', name: 'Veo', url: 'https://deepmind.google/technologies/veo/', category: AppCategory.LABS, color: '#34A853', description: 'Google\'s most capable generative video model for professional use.' },
  { id: 'imagefx', name: 'ImageFX', url: 'https://aitestkitchen.withgoogle.com/tools/image-fx', category: AppCategory.LABS, color: '#4285F4', description: 'Experimental tool for photorealistic image generation.' },
  { id: 'musicfx', name: 'MusicFX', url: 'https://aitestkitchen.withgoogle.com/tools/music-fx', category: AppCategory.LABS, color: '#EA4335', description: 'Create custom music tracks with advanced text-to-audio AI.' },
  { id: 'textfx', name: 'TextFX', url: 'https://textfx.withgoogle.com/', category: AppCategory.LABS, color: '#F4B400', description: 'AI-powered tools for rappers, writers, and wordsmiths.' },
  { id: 'illuminate', name: 'Illuminate', url: 'https://illuminate.google/', category: AppCategory.LABS, color: '#4285F4', description: 'Turn research papers into engaging audio discussions with AI.' },
  { id: 'gentype', name: 'GenType', url: 'https://labs.google/gentype', category: AppCategory.LABS, color: '#EA4335', description: 'Create custom alphabets using generative AI.' },
  { id: 'search_labs', name: 'Search Labs', url: 'https://labs.google.com/search', category: AppCategory.LABS, color: '#4285F4', description: 'Test early-stage Google Search experiments like SGE.' },
  { id: 'chrome_music_lab', name: 'Chrome Music Lab', url: 'https://musiclab.chromeexperiments.com/', category: AppCategory.LABS, color: '#EA4335', description: 'A website that makes learning music more accessible through fun, hands-on experiments.' },
  { id: 'astra', name: 'Project Astra', url: 'https://deepmind.google/technologies/gemini/project-astra/', category: AppCategory.LABS, color: '#4285F4', description: 'The future of universal AI agents that can see, hear, and reason in real-time.' },
  
  // --- EXPERIMENT COLLECTIONS (Spread) ---
  ...CHROME_MUSIC_LAB,
  ...AI_EXPERIMENTS,
  ...AR_VR_EXPERIMENTS,
  ...ARTS_CULTURE_EXPERIMENTS,
  ...ANDROID_EXPERIMENTS,

  // --- CLOUD INFRASTRUCTURE & DATA ---
  { id: 'google_cloud', name: 'Cloud Console', url: 'https://console.cloud.google.com', category: AppCategory.DEVELOPER, color: '#4285F4', description: 'Unified console for managing Google Cloud Platform resources.' },
  { id: 'vertex_ai', name: 'Vertex AI', url: 'https://cloud.google.com/vertex-ai', category: AppCategory.DEVELOPER, color: '#4285F4', description: 'Enterprise AI platform to build, deploy, and scale models.' },
  { id: 'bigquery', name: 'BigQuery', url: 'https://cloud.google.com/bigquery', category: AppCategory.DEVELOPER, color: '#4285F4', description: 'Serverless, highly scalable enterprise data warehouse.' },
  { id: 'spanner', name: 'Cloud Spanner', url: 'https://cloud.google.com/spanner', category: AppCategory.DEVELOPER, color: '#4285F4', description: 'Relational database with unlimited scale and global consistency.' },
  { id: 'firebase', name: 'Firebase', url: 'https://firebase.google.com', category: AppCategory.DEVELOPER, color: '#FFCA28', description: 'App development platform for building and growing apps.' },
  { id: 'cloud_run', name: 'Cloud Run', url: 'https://cloud.google.com/run', category: AppCategory.DEVELOPER, color: '#4285F4', description: 'Deploy containerized applications on a fully managed platform.' },
  { id: 'looker', name: 'Looker', url: 'https://looker.com/', category: AppCategory.BUSINESS, color: '#4285F4', description: 'Modern BI and data exploration for enterprise teams.' },
  { id: 'anthos', name: 'Anthos', url: 'https://cloud.google.com/anthos', category: AppCategory.DEVELOPER, color: '#4285F4', description: 'Platform for consistent application management across hybrid and multi-cloud.' },

  // --- DEVELOPER TOOLS & LANGUAGES ---
  { id: 'flutter', name: 'Flutter', url: 'https://flutter.dev', category: AppCategory.DEVELOPER, color: '#02569B', description: 'UI toolkit for building multi-platform apps from a single codebase.' },
  { id: 'project_idx', name: 'Project IDX', url: 'https://idx.google.com/', category: AppCategory.DEVELOPER, color: '#4285F4', description: 'An AI-augmented, multiplatform app development workflow in the cloud.' },
  { id: 'tensorflow', name: 'TensorFlow', url: 'https://www.tensorflow.org/', category: AppCategory.DEVELOPER, color: '#FF6F00', description: 'Open-source platform for end-to-end machine learning.' },
  { id: 'jax', name: 'JAX', url: 'https://github.com/google/jax', category: AppCategory.DEVELOPER, color: '#4285F4', description: 'High-performance numerical computing and ML research library.' },
  { id: 'golang', name: 'Go (Golang)', url: 'https://go.dev/', category: AppCategory.DEVELOPER, color: '#00ADD8', description: 'Simple, reliable, and efficient language built for the cloud.' },
  { id: 'colab', name: 'Colab', url: 'https://colab.research.google.com/', category: AppCategory.DEVELOPER, color: '#F9AB00', description: 'Write and execute Python in your browser for data science.' },
  { id: 'kaggle', name: 'Kaggle', url: 'https://www.kaggle.com/', category: AppCategory.DEVELOPER, color: '#20BEFF', description: 'The world\'s largest community of data scientists and ML engineers.' },
  { id: 'android_studio', name: 'Android Studio', url: 'https://developer.android.com/studio', category: AppCategory.DEVELOPER, color: '#3DDC84', description: 'The official IDE for Android development.' },
  { id: 'apps_script', name: 'Apps Script', url: 'https://www.google.com/script/start/', category: AppCategory.DEVELOPER, color: '#4285F4', description: 'Low-code platform for automating Google Workspace tasks.' },
  { id: 'adk', name: 'Android ADK', url: 'https://google.github.io/adk-docs/', category: AppCategory.DEVELOPER, color: '#3DDC84', description: 'Reference implementation for building Android accessories using the Open Accessory protocol.' },

  // --- BUSINESS, MARKETING & ADS ---
  { id: 'ads', name: 'Google Ads', url: 'https://ads.google.com', category: AppCategory.BUSINESS, color: '#4285F4', description: 'Reach customers across Google Search, YouTube, and the web.' },
  { id: 'adsense', name: 'AdSense', url: 'https://adsense.google.com', category: AppCategory.BUSINESS, color: '#F4B400', description: 'Monetize your website content by showing relevant ads.' },
  { id: 'admob', name: 'AdMob', url: 'https://admob.google.com', category: AppCategory.BUSINESS, color: '#EA4335', description: 'Monetize mobile apps with high-quality global advertising.' },
  { id: 'analytics', name: 'Analytics', url: 'https://analytics.google.com', category: AppCategory.BUSINESS, color: '#E37400', description: 'Measure user engagement and conversion across properties.' },
  { id: 'search_console', name: 'Search Console', url: 'https://search.google.com/search-console', category: AppCategory.BUSINESS, color: '#4285F4', description: 'Optimize your site\'s visibility in Google Search results.' },
  { id: 'merchant_center', name: 'Merchant Center', url: 'https://www.google.com/retail/solutions/merchant-center/', category: AppCategory.BUSINESS, color: '#4285F4', description: 'Manage how your store and product info appears on Google.' },
  { id: 'tag_manager', name: 'Tag Manager', url: 'https://tagmanager.google.com/', category: AppCategory.BUSINESS, color: '#4285F4', description: 'Manage all your website tags in one place.' },
  { id: 'google_domains', name: 'Google Domains', url: 'https://domains.google.com/', category: AppCategory.BUSINESS, color: '#4285F4', description: 'Register, manage, and grow your presence on the web with Google Domains.' },

  // --- PRODUCTIVITY & WORKSPACE ---
  { id: 'gmail', name: 'Gmail', url: 'https://mail.google.com', category: AppCategory.COMMUNICATION, color: '#EA4335', description: 'Secure, smart, and efficient email service.' },
  { id: 'meet', name: 'Meet', url: 'https://meet.google.com', category: AppCategory.COMMUNICATION, color: '#34A853', description: 'Enterprise-grade video conferencing for everyone.' },
  { id: 'chat', name: 'Chat', url: 'https://chat.google.com', category: AppCategory.COMMUNICATION, color: '#00AC47', description: 'Messaging and collaboration built for teams.' },
  { id: 'drive', name: 'Drive', url: 'https://drive.google.com', category: AppCategory.PRODUCTIVITY, color: '#FFD04B', description: 'Secure cloud storage and file sharing for businesses and individuals.' },
  { id: 'docs', name: 'Docs', url: 'https://docs.google.com', category: AppCategory.PRODUCTIVITY, color: '#4285F4', description: 'Collaborative word processing for modern teams.' },
  { id: 'sheets', name: 'Sheets', url: 'https://sheets.google.com', category: AppCategory.PRODUCTIVITY, color: '#34A853', description: 'Cloud-based spreadsheets with powerful data tools.' },
  { id: 'slides', name: 'Slides', url: 'https://slides.google.com', category: AppCategory.PRODUCTIVITY, color: '#F4B400', description: 'Professional deck creation and presentation.' },
  { id: 'forms', name: 'Forms', url: 'https://forms.google.com', category: AppCategory.PRODUCTIVITY, color: '#7248B9', description: 'Create surveys, quizzes, and data collection forms.' },
  { id: 'keep', name: 'Keep', url: 'https://keep.google.com', category: AppCategory.PRODUCTIVITY, color: '#F4B400', description: 'Quick notes, lists, and reminders that sync everywhere.' },
  { id: 'appsheet', name: 'AppSheet', url: 'https://www.appsheet.com/', category: AppCategory.PRODUCTIVITY, color: '#1A73E8', description: 'Build no-code applications for your business processes.' },
  { id: 'google_vids', name: 'Google Vids', url: 'https://workspace.google.com/products/vids/', category: AppCategory.PRODUCTIVITY, color: '#9C27B0', description: 'AI-powered video creation for professional work.' },

  // --- KNOWLEDGE, SEARCH & DATA ---
  { id: 'search', name: 'Google Search', url: 'https://www.google.com', category: AppCategory.KNOWLEDGE, color: '#4285F4', description: 'Access the world\'s information in an instant.' },
  { id: 'maps', name: 'Maps', url: 'https://maps.google.com', category: AppCategory.UTILITY, color: '#34A853', description: 'Real-time navigation, traffic, and local discovery.' },
  { id: 'earth', name: 'Earth', url: 'https://earth.google.com/', category: AppCategory.KNOWLEDGE, color: '#4285F4', description: 'Detailed satellite imagery and 3D globe visualization.' },
  { id: 'scholar', name: 'Scholar', url: 'https://scholar.google.com', category: AppCategory.KNOWLEDGE, color: '#4285F4', description: 'Search for scholarly literature across disciplines.' },
  { id: 'trends', name: 'Trends', url: 'https://trends.google.com/', category: AppCategory.KNOWLEDGE, color: '#4285F4', description: 'Explore what the world is searching for right now.' },
  { id: 'patents', name: 'Patents', url: 'https://patents.google.com/', category: AppCategory.KNOWLEDGE, color: '#4285F4', description: 'Search the full text of patents from around the world.' },
  { id: 'books', name: 'Books', url: 'https://books.google.com', category: AppCategory.KNOWLEDGE, color: '#EA4335', description: 'Search the world\'s most comprehensive index of books.' },
  { id: 'arts_culture', name: 'Arts & Culture', url: 'https://artsandculture.google.com/', category: AppCategory.KNOWLEDGE, color: '#4285F4', description: 'Explore art and history from global institutions.' },
  { id: 'finance', name: 'Finance', url: 'https://www.google.com/finance', category: AppCategory.KNOWLEDGE, color: '#137333', description: 'Real-time stock quotes, business news, and market trends.' },
  { id: 'flights', name: 'Flights', url: 'https://www.google.com/flights', category: AppCategory.KNOWLEDGE, color: '#4285F4', description: 'Plan trips and find the best fares across airlines.' },

  // --- HARDWARE & OPERATING SYSTEMS ---
  { id: 'android', name: 'Android', url: 'https://www.android.com/', category: AppCategory.HARDWARE, color: '#3DDC84', description: 'The world\'s most popular mobile operating system.' },
  { id: 'chromeos', name: 'ChromeOS', url: 'https://www.google.com/chromebook/chrome-os/', category: AppCategory.HARDWARE, color: '#4285F4', description: 'Fast, secure, and simple OS for modern computing.' },
  { id: 'pixel', name: 'Pixel', url: 'https://store.google.com/product/pixel_9', category: AppCategory.HARDWARE, color: '#4285F4', description: 'Google-engineered smartphones with advanced AI photography.' },
  { id: 'nest', name: 'Nest', url: 'https://home.google.com/', category: AppCategory.HARDWARE, color: '#4285F4', description: 'Smart home ecosystem for safety and efficiency.' },
  { id: 'fitbit', name: 'Fitbit', url: 'https://www.fitbit.com/', category: AppCategory.HARDWARE, color: '#00B0B9', description: 'Health and fitness wearables for active living.' },
  { id: 'wallet', name: 'Wallet', url: 'https://wallet.google/', category: AppCategory.UTILITY, color: '#4285F4', description: 'Secure digital wallet for essentials.' },
  { id: 'photos', name: 'Photos', url: 'https://photos.google.com', category: AppCategory.UTILITY, color: '#4285F4', description: 'Home for all your memories, intelligently organized.' },
  { id: 'google_takeout', name: 'Google Takeout', url: 'https://takeout.google.com/', category: AppCategory.UTILITY, color: '#4285F4', description: 'Export a copy of content in your Google Account to back it up or use it with a service outside of Google.' },

  // --- ENTERTAINMENT ---
  { id: 'youtube', name: 'YouTube', url: 'https://www.youtube.com', category: AppCategory.ENTERTAINMENT, color: '#FF0000', description: 'The world\'s leading video sharing and social platform.' },
  { id: 'youtube_music', name: 'YouTube Music', url: 'https://music.youtube.com', category: AppCategory.ENTERTAINMENT, color: '#FF0000', description: 'Stream millions of tracks and official albums.' },
  { id: 'google_tv', name: 'Google TV', url: 'https://tv.google/', category: AppCategory.ENTERTAINMENT, color: '#4285F4', description: 'Aggregated entertainment platform for streaming services.' },

  // --- PROGRAMS & TRAINING ---
  { id: 'grow_google', name: 'Grow with Google', url: 'https://grow.google/', category: AppCategory.OTHER, color: '#4285F4', description: 'Free training and certificates for high-growth careers.' },
  { id: 'skillshop', name: 'Skillshop', url: 'https://skillshop.withgoogle.com/', category: AppCategory.OTHER, color: '#4285F4', description: 'Master Google tools with free online certifications.' },
  { id: 'startup_school', name: 'Startup School', url: 'https://startup.google.com/school/', category: AppCategory.OTHER, color: '#4285F4', description: 'Structured training and mentorship for founders.' }
];
