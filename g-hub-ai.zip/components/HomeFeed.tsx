import React, { useState, useMemo } from 'react';
import { 
  GraduationCap, Gift, TrendingUp, ArrowRight, ExternalLink, Award, 
  Sparkles, Building, Users, BookOpen, Newspaper, Code, 
  HeartHandshake, UserPlus, Briefcase, Palette, Beaker, Globe,
  ShieldCheck, Coins, School, Microscope, Monitor, Smartphone,
  Zap, Database, Landmark, PenTool, Lightbulb, Target, Trophy, Compass,
  Terminal, Shield, Laptop, Github, Rocket
} from 'lucide-react';

type ProgramCategory = 'All' | 'Learning' | 'Business' | 'Developers' | 'Impact';

const PROGRAMS = [
  // --- LEARNING & SKILLS ---
  {
    category: 'Learning',
    type: 'Professional Skills',
    title: 'Google Skillshop',
    description: 'Master the Google tools you use at work with free online training. Get certified in Google Ads, Analytics, and more.',
    link: 'https://skillshop.withgoogle.com/',
    cta: 'Browse Courses',
    color: 'bg-[#E8F0FE] text-[#1967D2] dark:bg-[#1C2B3E] dark:text-[#8AB4F8]',
    icon: Trophy
  },
  {
    category: 'Learning',
    type: 'AI Training',
    title: 'Google AI Essentials',
    description: 'A new self-paced course designed to help people in all roles learn how to use AI to be more productive at work.',
    link: 'https://grow.google/ai-essentials/',
    cta: 'Learn AI Skills',
    color: 'bg-[#E8F0FE] text-[#1967D2] dark:bg-[#1C2B3E] dark:text-[#8AB4F8]',
    icon: Sparkles
  },
  {
    category: 'Learning',
    type: 'Certificates',
    title: 'Google Career Certificates',
    description: 'Get job-ready for high-growth fields like UX Design, Cybersecurity, and Data Analytics. No experience required.',
    link: 'https://grow.google/certificates/',
    cta: 'Get Certified',
    color: 'bg-[#E8F0FE] text-[#1967D2] dark:bg-[#1C2B3E] dark:text-[#8AB4F8]',
    icon: GraduationCap
  },

  // --- DEVELOPERS & CLOUD (EXPANDED) ---
  {
    category: 'Developers',
    type: 'Elite Program',
    title: 'Google Developer Experts',
    description: 'The GDE program is a global network of highly experienced technology experts, influencers, and thought leaders.',
    link: 'https://developers.google.com/community/experts',
    cta: 'Learn About GDE',
    color: 'bg-[#E6F4EA] text-[#137333] dark:bg-[#1E2F23] dark:text-[#81C995]',
    icon: Rocket
  },
  {
    category: 'Developers',
    type: 'Advocacy',
    title: 'Women Techmakers',
    description: 'Providing visibility, community, and resources for women in technology to build a world where all women thrive.',
    link: 'https://www.womentechmakers.com/',
    cta: 'Join Community',
    color: 'bg-[#E6F4EA] text-[#137333] dark:bg-[#1E2F23] dark:text-[#81C995]',
    icon: HeartHandshake
  },
  {
    category: 'Developers',
    type: 'Cloud Community',
    title: 'Cloud Innovators',
    description: 'Get the latest tech news, invites to exclusive events, and a free trial of Cloud Skills Boost.',
    link: 'https://cloud.google.com/innovators',
    cta: 'Become Innovator',
    color: 'bg-[#E6F4EA] text-[#137333] dark:bg-[#1E2F23] dark:text-[#81C995]',
    icon: Zap
  },
  {
    category: 'Developers',
    type: 'Open Source',
    title: 'Google Open Source',
    description: 'Learn how Google supports open source through projects, communities, and advocacy for a healthier web.',
    link: 'https://opensource.google/',
    cta: 'Explore Projects',
    color: 'bg-[#E6F4EA] text-[#137333] dark:bg-[#1E2F23] dark:text-[#81C995]',
    icon: Github
  },
  {
    category: 'Developers',
    type: 'Community',
    title: 'Google Developer Groups',
    description: 'Join a GDG to meet other local developers and learn about new technologies through workshops and talks.',
    link: 'https://developers.google.com/community/gdg',
    cta: 'Find a Group',
    color: 'bg-[#E6F4EA] text-[#137333] dark:bg-[#1E2F23] dark:text-[#81C995]',
    icon: Users
  },
  {
    category: 'Developers',
    type: 'Dev Training',
    title: 'Cloud Skills Boost',
    description: 'Hands-on labs to build your cloud expertise. Earn skill badges to share your proficiency with the world.',
    link: 'https://www.cloudskillsboost.google/',
    cta: 'Start Labs',
    color: 'bg-[#E6F4EA] text-[#137333] dark:bg-[#1E2F23] dark:text-[#81C995]',
    icon: Award
  },

  // --- BUSINESS & STARTUPS ---
  {
    category: 'Business',
    type: 'Cloud Bonus',
    title: 'Google Cloud Free Tier',
    description: 'Get $300 in free credits to explore Cloud products and use 20+ "Always Free" products like Compute Engine.',
    link: 'https://cloud.google.com/free',
    cta: 'Claim Credits',
    color: 'bg-[#FCE8E6] text-[#C5221F] dark:bg-[#3E1F1E] dark:text-[#F28B82]',
    icon: Gift
  },
  {
    category: 'Business',
    type: 'Entrepreneurship',
    title: 'Google for Startups',
    description: 'Access the best of Google\'s technology and community to help your startup grow. Includes equity-free funding.',
    link: 'https://startup.google.com/',
    cta: 'View Programs',
    color: 'bg-[#FEF7E0] text-[#D93025] dark:bg-[#2D2A1D] dark:text-[#FDD663]',
    icon: Building
  },

  // --- IMPACT & RESEARCH ---
  {
    category: 'Impact',
    type: 'Social',
    title: 'Google for Nonprofits',
    description: 'Empower your nonprofit with Google Workspace, Ad Grants, and specialized social impact programs.',
    link: 'https://www.google.com/nonprofits/',
    cta: 'Apply Now',
    color: 'bg-[#FCE8F3] text-[#D01884] dark:bg-[#3E1F2E] dark:text-[#F06292]',
    icon: HeartHandshake
  },
  {
    category: 'Impact',
    type: 'Media',
    title: 'Google News Initiative',
    description: 'Supporting the future of journalism through innovation, training, and programs for publishers of all sizes.',
    link: 'https://newsinitiative.withgoogle.com/',
    cta: 'Explore GNI',
    color: 'bg-[#FCE8F3] text-[#D01884] dark:bg-[#3E1F2E] dark:text-[#F06292]',
    icon: Newspaper
  }
];

export const HomeFeed: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<ProgramCategory>('All');

  const filteredPrograms = useMemo(() => {
    if (activeCategory === 'All') return PROGRAMS;
    return PROGRAMS.filter(p => p.category === activeCategory);
  }, [activeCategory]);

  const categories: ProgramCategory[] = ['All', 'Learning', 'Business', 'Developers', 'Impact'];

  return (
    <div className="w-full max-w-[1400px] mx-auto animate-slideUpFade" style={{ animationDelay: '1.2s' }}>
      <div className="flex flex-col gap-8 mb-8 px-4">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-5 h-5 text-m3-primary" />
              <h2 className="text-2xl font-display font-medium text-m3-on-surface">Ecosystem & Growth</h2>
            </div>
            <p className="text-sm text-m3-on-surface-variant max-w-xl">
              Professional training, specialized communities, and elite developer programs to accelerate your potential.
            </p>
          </div>
          <div className="text-[10px] font-bold text-m3-on-surface-variant/40 uppercase tracking-[0.2em]">
            {filteredPrograms.length} Resources
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`
                px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 flex items-center gap-2
                ${activeCategory === cat 
                  ? 'bg-m3-secondary-container text-m3-on-secondary-container shadow-elevation-1' 
                  : 'bg-m3-surface-container-high text-m3-on-surface-variant hover:bg-m3-surface-container-highest'}
              `}
            >
              {cat === 'Learning' && <BookOpen className="w-4 h-4" />}
              {cat === 'Developers' && <Code className="w-4 h-4" />}
              {cat === 'All' ? 'Discover All' : cat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 px-4 pb-24">
        {filteredPrograms.map((item, index) => (
          <div 
            key={`${item.title}-${index}`}
            className="group relative overflow-hidden rounded-[28px] bg-m3-surface-container-low border border-m3-outline-variant/10 hover:border-m3-primary/30 hover:shadow-elevation-3 transition-all duration-500 ease-emphasized flex flex-col h-full hover:scale-[1.02]"
          >
            <div className={`p-8 flex items-center justify-between ${item.color} bg-opacity-40 transition-colors duration-500 group-hover:bg-opacity-60`}>
               <item.icon className="w-10 h-10 opacity-90 group-hover:scale-110 group-hover:rotate-6 transition-transform duration-500" strokeWidth={1.5} />
               <div className="text-right">
                  <div className="font-display font-bold text-[9px] uppercase tracking-[0.2em] opacity-60 mb-1">
                    {item.type}
                  </div>
                  <div className="w-6 h-1 bg-current opacity-20 ml-auto rounded-full"></div>
               </div>
            </div>

            <div className="p-8 flex flex-col flex-1 justify-between bg-m3-surface-container-low">
               <div>
                 <h3 className="text-lg font-display font-medium text-m3-on-surface mb-3 group-hover:text-m3-primary transition-colors leading-tight">
                   {item.title}
                 </h3>
                 <p className="text-sm text-m3-on-surface-variant leading-relaxed mb-8 opacity-80 group-hover:opacity-100 transition-opacity line-clamp-3">
                   {item.description}
                 </p>
               </div>
               
               <div className="flex items-center justify-between">
                 <a 
                   href={item.link}
                   target="_blank"
                   rel="noopener noreferrer"
                   className="inline-flex items-center px-4 py-2.5 rounded-full bg-m3-surface-container-high text-xs font-medium text-m3-primary hover:bg-m3-primary hover:text-m3-on-primary transition-all duration-300 group/link shadow-sm hover:shadow-md"
                 >
                   {item.cta}
                   <ArrowRight className="w-3.5 h-3.5 ml-2 group-hover/link:translate-x-1 transition-transform" />
                 </a>
                 <ExternalLink className="w-4 h-4 opacity-10 text-m3-on-surface group-hover:opacity-30 transition-opacity" />
               </div>
            </div>
          </div>
        ))}
      </div>

      <div className="px-4 pb-24">
        <div className="rounded-[32px] bg-m3-surface-container p-8 md:p-10 flex flex-col md:flex-row items-center justify-between gap-8 border border-m3-outline-variant/20 relative overflow-hidden group/news shadow-elevation-1">
            <div className="absolute top-[-50%] right-[-10%] w-64 h-64 bg-m3-primary/5 rounded-full blur-3xl pointer-events-none transition-transform duration-1000 group-hover/news:scale-150"></div>
            
            <div className="flex flex-col md:flex-row items-start md:items-center gap-6 relative z-10">
               <div className="p-4 rounded-3xl bg-m3-primary text-m3-on-primary shadow-elevation-1 group-hover/news:scale-110 transition-transform duration-500">
                  <Terminal className="w-8 h-8" />
               </div>
               <div>
                  <h3 className="text-2xl font-medium text-m3-on-surface font-display mb-2">Developer Hub</h3>
                  <p className="text-base text-m3-on-surface-variant max-w-2xl leading-relaxed">
                     Explore Google’s documentation, open source projects, and the global developer community to build the next generation of software.
                  </p>
               </div>
            </div>
            <button 
               onClick={() => {
                  window.open('https://developers.google.com/', '_blank');
               }}
               className="shrink-0 px-8 py-4 rounded-full bg-m3-on-surface text-m3-surface hover:bg-m3-on-surface-variant transition-all text-sm font-bold flex items-center gap-3 shadow-elevation-1 hover:shadow-elevation-2 relative z-10"
            >
               Google Developers
               <ExternalLink className="w-4 h-4" />
            </button>
         </div>
      </div>
    </div>
  );
};